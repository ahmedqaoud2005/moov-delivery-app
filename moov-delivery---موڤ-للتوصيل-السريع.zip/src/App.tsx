import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  ChevronLeft, 
  Plus, 
  Star, 
  Send, 
  Trash2, 
  Edit2, 
  MapPin, 
  User,
  MessageSquare,
  MessageCircle,
  Settings,
  X,
  ArrowRight,
  Wallet,
  ShoppingBag,
  CreditCard,
  CheckCircle2,
  AlertCircle,
  Camera,
  Loader2,
  Lock,
  Unlock,
  LogOut,
  MoreVertical,
  Globe,
  Moon,
  Sun,
  Mail,
  Search,
  Navigation,
  Clock,
  ThumbsUp,
  Gift,
  Phone,
  Twitter,
  Instagram,
  PlayCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';

// @ts-ignore
import icon from 'leaflet/dist/images/marker-icon.png';
// @ts-ignore
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

const springTransition = {
  type: "spring",
  stiffness: 300,
  damping: 30,
  mass: 1
};

const DriverIcon = L.divIcon({
  className: 'custom-div-icon',
  html: `<div style="background-color: #FFD700; width: 30px; height: 30px; border-radius: 50%; border: 2px solid white; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 10px rgba(255,215,0,0.5);"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg></div>`,
  iconSize: [30, 30],
  iconAnchor: [15, 15]
});

const CustomerIcon = L.divIcon({
  className: 'custom-div-icon',
  html: `<div style="background-color: #BF00FF; width: 30px; height: 30px; border-radius: 50%; border: 2px solid white; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 10px rgba(191,0,255,0.5);"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>`,
  iconSize: [30, 30],
  iconAnchor: [15, 15]
});

function MapUpdater({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, map.getZoom());
  }, [center, map]);
  return null;
}
import { Region, Driver, ChatMessage, ViewState, Order, LogEntry, UserProfile, JobApplication, ChatRoom } from './types';

const INITIAL_REGIONS: Region[] = [
  {
    id: 'gaza_city',
    name: 'مدينة غزة',
    drivers: [
      { id: 'driver_gaza1', name: 'Captain 6', rating: 5.0, ratingCount: 0, phone: '0590000006', username: 'Captain6', password: 'gaza1', currentLocation: { lat: 31.5000, lng: 34.4667 } },
      { id: 'driver_gaza2', name: 'Captain 7', rating: 5.0, ratingCount: 0, phone: '0590000007', username: 'Captain7', password: 'gaza2', currentLocation: { lat: 31.5010, lng: 34.4680 } },
    ],
    restaurants: [
      { id: 'res_1', name: 'مطعم زاد الخير' },
      { id: 'res_2', name: 'مطعم التايلاندي' },
      { id: 'res_3', name: 'مطعم بالميرا' }
    ]
  },
  {
    id: 'der_el_balah',
    name: 'دير البلح',
    drivers: [
      { id: 'driver_cap1', name: 'Captain 1', rating: 5.0, ratingCount: 0, phone: '0590000001', username: 'Captain1', password: 'cap10', currentLocation: { lat: 31.4175, lng: 34.3509 } },
      { id: 'driver_cap2', name: 'Captain 2', rating: 5.0, ratingCount: 0, phone: '0590000002', username: 'Captain2', password: 'cat15', currentLocation: { lat: 31.4160, lng: 34.3480 } },
      { id: 'driver_cap3', name: 'Captain 3', rating: 5.0, ratingCount: 0, phone: '0590000003', username: 'Captain3', password: 'cat20', currentLocation: { lat: 31.4180, lng: 34.3520 } },
      { id: 'driver_cap4', name: 'Captain 4', rating: 5.0, ratingCount: 0, phone: '0590000004', username: 'Captain4', password: 'cat25', currentLocation: { lat: 31.4190, lng: 34.3530 } },
      { id: 'driver_cap5', name: 'Captain 5', rating: 5.0, ratingCount: 0, phone: '0590000005', username: 'Captain5', password: 'cat30', currentLocation: { lat: 31.4200, lng: 34.3540 } },
    ],
    restaurants: [
      { id: 'res_4', name: 'مطعم سيدار' },
      { id: 'res_5', name: 'مطعم حيفا' }
    ]
  },
  {
    id: 'nuseirat',
    name: 'النصيرات',
    drivers: [
      { id: 'driver_nus1', name: 'Captain 8', rating: 5.0, ratingCount: 0, phone: '0590000008', username: 'Captain8', password: 'nus1', currentLocation: { lat: 31.4481, lng: 34.3925 } },
      { id: 'driver_nus2', name: 'Captain 9', rating: 5.0, ratingCount: 0, phone: '0590000009', username: 'Captain9', password: 'nus2', currentLocation: { lat: 31.4490, lng: 34.3940 } },
    ],
    restaurants: [
      { id: 'res_6', name: 'مطعم أبو صبحي' }
    ]
  },
  {
    id: 'khan_yunis',
    name: 'خانيونس',
    drivers: [
      { id: 'driver_khan1', name: 'Captain 10', rating: 5.0, ratingCount: 0, phone: '0590000010', username: 'Captain10', password: 'khan1', currentLocation: { lat: 31.3458, lng: 34.3022 } },
      { id: 'driver_khan2', name: 'Captain 11', rating: 5.0, ratingCount: 0, phone: '0590000011', username: 'Captain11', password: 'khan2', currentLocation: { lat: 31.3470, lng: 34.3040 } },
    ],
    restaurants: [
      { id: 'res_7', name: 'مطعم القلعة' }
    ]
  },
  {
    id: 'rafah',
    name: 'رفح',
    drivers: [
      { id: 'driver_rafah1', name: 'Captain 12', rating: 5.0, ratingCount: 0, phone: '0590000012', username: 'Captain12', password: 'rafah1', currentLocation: { lat: 31.2847, lng: 34.2533 } },
      { id: 'driver_rafah2', name: 'Captain 13', rating: 5.0, ratingCount: 0, phone: '0590000013', username: 'Captain13', password: 'rafah2', currentLocation: { lat: 31.2860, lng: 34.2550 } },
    ],
    restaurants: [
      { id: 'res_8', name: 'مطعم العودة' }
    ]
  },
  {
    id: 'jabalia',
    name: 'جباليا',
    drivers: [
      { id: 'driver_jab1', name: 'Captain 14', rating: 5.0, ratingCount: 0, phone: '0590000014', username: 'Captain14', password: 'jab1', currentLocation: { lat: 31.5297, lng: 34.4828 } },
      { id: 'driver_jab2', name: 'Captain 15', rating: 5.0, ratingCount: 0, phone: '0590000015', username: 'Captain15', password: 'jab2', currentLocation: { lat: 31.5310, lng: 34.4840 } },
    ],
    restaurants: [
      { id: 'res_9', name: 'مطعم السلام' }
    ]
  }
];

const MOCK_ORDERS: Order[] = [];

const TRANSLATIONS: Record<string, any> = {
  ar: {
    settings: 'الإعدادات',
    language: 'اللغة',
    theme: 'المظهر',
    dark: 'ليلي',
    light: 'نهاري',
    complaints: 'الشكاوي والاقتراحات',
    logout: 'تسجيل الخروج',
    wallet: 'المحفظة',
    orders: 'الطلبات',
    preparing: 'قيد التجهيز',
    delivering: 'يتم التوصيل',
    arriving: 'قيد الوصول',
    completed: 'تم الإنجاز',
    eta: 'الوقت التقديري',
    points: 'رصيد نقاطك (ILS)',
    discount: 'خصم خاص',
    tracking: 'تتبع الطلب',
    rate_driver: 'تقييم السائق',
    support: 'تواصل مع الدعم الفني',
    admin_logs: 'سجل العمليات',
    contact_driver: 'تواصل مع السائق (SMS)',
    contact_admin: 'تواصل مع الإدارة',
    free_order: 'طلب مجاني متاح!',
    loyalty_msg: 'احصل على خصم بعد 5 طلبات، وطلب مجاني بعد 15 طلب! (1 نقطة = 1 شيكل)',
    map_loading: 'جاري تحميل الخريطة...',
    login: 'تسجيل الدخول',
    login_msg: 'أدخل بياناتك للوصول إلى حسابك',
    username_label: 'اسم المستخدم',
    password_label: 'كلمة المرور',
    login_error: 'بيانات الدخول غير صحيحة!',
    login_error_lockout: 'تم حظرك لمدة ساعتين بسبب محاولات تسجيل دخول خاطئة متكررة.',
    cancel: 'إلغاء',
    new_order_title: 'طلب توصيل جديد',
    customer_name: 'اسم الزبون',
    region_placeholder: 'المنطقة (اكتبها يدوياً)',
    order_details: 'تفاصيل الطلب',
    suggested_price: 'السعر المقترح (نقاط)',
    send_order: 'إرسال الطلب',
    job_application_title: 'طلب توظيف سائق',
    job_terms: 'شروط العمل',
    agree_terms: 'أوافق على الشروط وأرغب بالتقديم',
    full_name: 'الاسم الكامل',
    age: 'العمر',
    dob: 'تاريخ الميلاد',
    id_photo: 'صورة الهوية',
    upload_id: 'ارفع صورة الهوية',
    back: 'رجوع',
    confirm_delete: 'تأكيد الحذف',
    delete_msg: 'هل أنت متأكد من حذف {name}؟',
    delete: 'حذف',
    palpay_payment: 'دفع العمولة عبر PalPay',
    insufficient_balance: 'رصيد نقاطك غير كافٍ',
    pay_to_wallet: 'ادفع إلى المحفظة',
    success: 'تم بنجاح',
    ok: 'حسناً',
    chat_placeholder: 'اكتب رسالة...',
    order_success_msg: 'تم نشر طلبك بنجاح! سيقوم أقرب سائق بقبول الطلب والتواصل معك.',
    chat_welcome: 'أهلاً بك! أنا {name}، كيف يمكنني مساعدتك؟',
    chat_try_hello: 'جرب إرسال "مرحبا"',
    connection_status: 'حالة الاتصال',
    offline_mode_desc: 'أنت الآن في وضع عدم الاتصال. سيتم إرسال تفاصيل أي طلب تقبله عبر رسائل SMS لضمان استمرارية العمل.',
    commission_desc: 'يتم خصم عمولة قدرها 2 نقطة لكل 10 نقاط من قيمة الطلب.',
    new_customer: 'زبون جديد',
    reserved_customer: 'زبون محجوز',
    details_unlocked: 'تم فتح تفاصيل الزبون',
    eta_placeholder: 'الوقت التقديري (مثلاً: 15 دقيقة)',
    update_eta: 'تحديث ETA',
    no_drivers: 'لا يوجد سائقون في هذه المنطقة.',
    start_chat_with: 'ابدأ المحادثة مع {name}',
    pay_now_to_accept: 'ادفع الآن لتتمكن من استلام طلب {name}',
    job_received_alert: 'تم استلام طلبك بنجاح! سيقوم الدعم الفني بالتواصل معك قريباً.',
    enter_username: 'أدخل اسم المستخدم',
    enter_name: 'أدخل اسمك',
    region_manual: 'مثلاً: دير البلح - شارع البحر',
    what_to_deliver: 'ماذا تريد أن نوصل لك؟',
    price_eg: 'مثلاً: 20',
    credibility: 'المصداقية والأمانة في التعامل.',
    own_bike: 'امتلاك دراجة هوائية أو كهربائية.',
    commitment: 'الالتزام بمواعيد التوصيل.',
    id_photo_label: 'صورة الهوية',
    upload_id_btn: 'ارفع صورة الهوية',
    admin_logs_title: 'سجل العمليات',
    log_order_received: 'تم استلام طلب جديد من {customer} بسعر {price} نقطة في منطقة {region}',
    log_region_added: 'تم إضافة منطقة جديدة: {name}',
    log_region_deleted: 'تم حذف منطقة: {id}',
    log_driver_added: 'تم إضافة سائق جديد: {name} في منطقة {region}',
    log_driver_deleted: 'تم حذف سائق: {id} من منطقة {region}',
    log_payment_verified: 'تم تأكيد دفع عمولة الطلب {id} بقيمة {amount} نقطة من قبل السائق.',
    log_loyalty_discount: 'مبروك! حصلت على خصم خاص لولائك بعد {count} طلبات.',
    log_order_completed: 'تم إنجاز الطلب {id} بنجاح.',
    log_status_updated: 'تحديث حالة الطلب {id} إلى {status}',
    log_rating_received: 'تم تقييم السائق {id} بـ {rating} نجوم',
    log_points_redeemed: 'تم استبدال 75 نقطة بطلب مجاني',
    log_commission_received: 'تم استلام عمولة بقيمة {amount} نقطة للطلب {id}.',
    log_region_updated: 'تم تحديث بيانات المنطقة: {name}',
    log_driver_updated: 'تم تحديث بيانات السائق: {name} في منطقة {region}',
    log_theme_changed: 'تم تغيير المظهر إلى {theme}',
    log_language_changed: 'تم تغيير اللغة إلى {lang}',
    add_region: 'إضافة منطقة جديدة',
    add_driver: 'إضافة سائق جديد',
    edit_region: 'تعديل المنطقة',
    edit_driver: 'تعديل السائق',
    region_name: 'اسم المنطقة',
    driver_name: 'اسم السائق',
    rating: 'التقييم',
    phone: 'رقم الهاتف',
    save: 'حفظ',
    admin_account: 'حساب الإدارة',
    no_orders: 'لا توجد طلبات متاحة حالياً.',
    commission: 'العمولة',
    accept_order: 'قبول الطلب',
    verified: 'تم التحقق',
    upload_receipt: 'إرفاق إشعار الدفع',
    verify_ai: 'جاري التحقق بالذكاء الاصطناعي...',
    not_verified: 'فشل التحقق',
    confirm_payment: 'تأكيد الدفع',
    developed_by: 'التطبيق مطور بواسطة شركة سكاي غزة التقنية',
    premium_benefits: 'هدايا وخصومات قيمة + مشاهدة 8 إعلانات مميزة يومياً',
    premium_payment_title: 'للإشتراك بنسخة المميزة',
    premium_payment_desc: 'يرجى تحويل 18 شيكل للمحفظة 0594840428 وإرفاق صورة لاشعار الدفع',
    job_desc: 'هل تمتلك دراجة هوائية أو كهربائية؟ هل تتميز بالمصداقية والأمانة؟ انضم إلينا الآن كشريك توصيل.',
    connection_status_label: 'حالة الاتصال',
    available_orders: 'الطلبات المتاحة',
    active_orders: 'طلباتك النشطة',
    chat_title: 'المحادثة',
    complete_order_btn: 'إنجاز الطلب',
    start_chat_msg: 'ابدأ المحادثة مع {name}',
    try_hello_msg: 'جرب إرسال "مرحبا"',
    pay_to_accept_msg: 'ادفع الآن لتتمكن من استلام طلب {name}',
    sms_body: 'مرحباً، بخصوص الطلب رقم {id}...',
    your_location_label: 'موقعك',
    driver_label: 'السائق',
    job_success: 'تم التقديم بنجاح! سيقوم الدعم الفني بالرد عليك في أسرع وقت ممكن لقبولك.',
    contact_email_label: 'البريد الإلكتروني للتواصل',
    email_placeholder: 'example@mail.com',
    job_terms_email: 'توفير بريد إلكتروني فعال للتواصل.',
    no_logs: 'لا توجد سجلات مسجلة بعد.',
    your_location: 'موقعك',
    driver_location: 'موقع السائق',
    rate_msg: 'شكراً لتقييمك! ملاحظاتك تساعدنا على التحسن.',
    free_order_redeemed: 'مبروك! تم تفعيل طلبك المجاني القادم.',
    points_needed: 'تحتاج إلى المزيد من النقاط للحصول على طلب مجاني.',
    preparing_order: 'جاري تجهيز الطلب',
    waiting_payment: 'بانتظار الدفع',
    accepted: 'تم القبول',
    pending: 'قيد الانتظار',
    apply_job: 'انضم كسائق',
    order_id: 'رقم الطلب',
    customer: 'الزبون',
    amount: 'المبلغ',
    status: 'الحالة',
    actions: 'الإجراءات',
    job_application: 'التقدم للوظيفة الآن',
    job_applications: 'طلبات التوظيف',
    follow_us: 'متابعة جميع حساباتنا للعلم بالجوائز والخصم',
    city_address: 'عنوان السكن الحالي (المدينة)',
    delivery_experience: 'هل لديك خبرة سابقة في التوصيل؟',
    experience_placeholder: 'مثلاً: نعم، سنتين في غزة',
    welcome_title: 'أهلاً بك في MOOV',
    welcome_subtitle: 'أسرع خدمة توصيل في غزة',
    switch_account: 'تبديل الحساب',
    my_points: 'نقاطي',
    id_number: 'رقم الهوية',
    whatsapp: 'واتساب',
    facebook: 'فيسبوك',
    instagram: 'إنستغرام',
    enter_referral: 'أدخل كود الإحالة',
    redeem: 'تفعيل',
    referral_redeemed: 'تم تفعيل الكود بنجاح! حصلت على 5 نقاط.',
    invalid_referral: 'كود غير صحيح.',
    welcome_arabic: 'موڤ للتوصيل السريع',
    login_google: 'الدخول بواسطة جوجل',
    login_guest: 'الدخول كضيف',
    login_direct: 'دخول مباشر (اسم/بريد)',
    login_driver: 'دخول السائقين',
    back_to_login: 'العودة لصفحة تسجيل الدخول',
    name_label: 'الاسم الكامل',
    email_label: 'البريد الإلكتروني',
    guest_restriction: '⚠️ بصفتك ضيفاً، لا يمكنك الحصول على هدايا أو خصومات. سجل دخولك بالبريد الإلكتروني للاستفادة من كافة المزايا.',
    notification_permission: 'هل ترغب في تفعيل الإشعارات لتصلك تحديثات الطلبات والخصومات؟',
    allow: 'سماح',
    deny: 'رفض',
    new_discount_alert: 'توجد خصومات جديدة متاحة الآن! تفقد المحفظة.',
    login_success_alert: 'تم تسجيل الدخول بنجاح! أهلاً بك {name}.',
    order_placed_alert: 'تم إرسال طلبك بنجاح! سيتم إشعارك عند قبول السائق للطلب.',
    referral_code: 'كود الإحالة (اختياري)',
    referral_success: 'تم تفعيل كود الإحالة! حصل صاحب الكود على 1 نقطة.',
    your_referral_code: 'كود الإحالة الخاص بك',
    premium_membership: 'عضوية Premium',
    premium_desc: 'احصل على نقاط مضاعفة وخصومات حصرية!',
    subscribe_premium: 'اشترك الآن',
    is_premium: 'أنت عضو مميز 💎',
    referral_points_msg: 'شارك كودك واحصل على 1 نقطة لكل صديق يسجل!',
    search_placeholder: 'ابحث عن منطقة أو مطعم...',
    mailbox: 'صندوق البريد',
    mailbox_desc: 'تلقى العروض الحصرية والرسائل الهامة هنا',
    no_messages: 'لا توجد رسائل جديدة حالياً',
    back_box: 'صندوق العودة',
    chat_list_title: 'المحادثات',
    admin_password_required: 'كلمة مرور الإدارة مطلوبة',
    enter_admin_password: 'أدخل كلمة مرور الإدارة',
    watch_ad: 'شاهد إعلان واربح',
    ad_limit_reached: 'لقد وصلت للحد الأقصى اليوم (4 إعلانات)',
    ad_reward_success: 'مبروك! حصلت على 0.5 نقطة',
    live_tracking: 'تتبع حي',
    delay_discount_applied: 'نعتذر عن التأخير! تم تطبيق خصم تلقائي على طلبك.',
    no_active_chats: 'لا توجد محادثات نشطة',
    remember_me: 'تذكرني',
    ad_watched_today: 'إعلانات اليوم: {count}/4',
    watch_ad_btn: 'شاهد إعلان لربح 0.5 نقطة',
    discount_notice: 'تم تطبيق خصم {amount} نقطة بسبب التأخير',
    refresh_rate: 'معدل تحديث التطبيق',
    refresh_rate_desc: 'اختر معدل التحديث المفضل لهاتفك (Hz)'
  },
  en: {
    settings: 'Settings',
    language: 'Language',
    theme: 'Theme',
    dark: 'Dark',
    light: 'Light',
    complaints: 'Complaints & Suggestions',
    logout: 'Logout',
    wallet: 'Wallet',
    orders: 'Orders',
    preparing: 'Preparing',
    delivering: 'Delivering',
    arriving: 'Arriving',
    completed: 'Completed',
    eta: 'ETA',
    points: 'Points Balance (ILS)',
    discount: 'Special Discount',
    tracking: 'Order Tracking',
    rate_driver: 'Rate Driver',
    support: 'Contact Technical Support',
    admin_logs: 'Admin Logs',
    contact_driver: 'Contact Driver (SMS)',
    contact_admin: 'Contact Admin',
    free_order: 'Free Order Available!',
    loyalty_msg: 'Get a discount after 5 orders, and a free order after 15! (1 point = 1 ILS)',
    map_loading: 'Loading map...',
    login: 'Login',
    login_msg: 'Enter your credentials to access your account',
    username_label: 'Username',
    password_label: 'Password',
    login_error: 'Invalid credentials!',
    login_error_lockout: 'You have been blocked for 2 hours due to repeated incorrect login attempts.',
    cancel: 'Cancel',
    new_order_title: 'New Delivery Order',
    customer_name: 'Customer Name',
    region_placeholder: 'Region (Type manually)',
    order_details: 'Order Details',
    suggested_price: 'Suggested Price (Points)',
    send_order: 'Send Order',
    job_application_title: 'Driver Job Application',
    job_terms: 'Work Terms',
    agree_terms: 'I agree and want to apply',
    full_name: 'Full Name',
    age: 'Age',
    dob: 'Date of Birth',
    id_photo: 'ID Photo',
    upload_id: 'Upload ID Photo',
    back: 'Back',
    confirm_delete: 'Confirm Delete',
    delete_msg: 'Are you sure you want to delete {name}?',
    delete: 'Delete',
    palpay_payment: 'Pay Commission via PalPay',
    insufficient_balance: 'Insufficient points balance',
    pay_to_wallet: 'Pay to Wallet',
    success: 'Success',
    ok: 'OK',
    chat_placeholder: 'Type a message...',
    order_success_msg: 'Your order has been posted! The nearest driver will accept it and contact you.',
    chat_welcome: 'Welcome! I am {name}, how can I help you?',
    chat_try_hello: 'Try sending "Hello"',
    connection_status: 'Connection Status',
    offline_mode_desc: 'You are now offline. Details of any accepted order will be sent via SMS to ensure continuity.',
    commission_desc: 'A commission of 2 points is deducted for every 10 points of order value.',
    new_customer: 'New Customer',
    reserved_customer: 'Reserved Customer',
    details_unlocked: 'Customer details unlocked',
    eta_placeholder: 'ETA (e.g., 15 mins)',
    update_eta: 'Update ETA',
    no_drivers: 'No drivers in this region.',
    start_chat_with: 'Start chat with {name}',
    pay_now_to_accept: 'Pay now to accept {name}\'s order',
    job_received_alert: 'Your application has been received successfully! Support will contact you soon.',
    enter_username: 'Enter username',
    enter_name: 'Enter your name',
    region_manual: 'e.g., Deir al-Balah - Sea St',
    what_to_deliver: 'What do you want us to deliver?',
    price_eg: 'e.g., 20',
    credibility: 'Credibility and honesty in dealing.',
    own_bike: 'Owning a bicycle or electric bike.',
    commitment: 'Commitment to delivery times.',
    id_photo_label: 'ID Photo',
    upload_id_btn: 'Upload ID Photo',
    admin_logs_title: 'Admin Logs',
    log_order_received: 'New order received from {customer} for {price} points in {region}',
    log_region_added: 'New region added: {name}',
    log_region_deleted: 'Region deleted: {id}',
    log_driver_added: 'New driver added: {name} in {region}',
    log_driver_deleted: 'Driver deleted: {id} from {region}',
    log_payment_verified: 'Order {id} commission of {amount} points verified by driver.',
    log_loyalty_discount: 'Congratulations! Got a special loyalty discount after {count} orders.',
    log_order_completed: 'Order {id} completed successfully.',
    log_status_updated: 'Order {id} status updated to {status}',
    log_rating_received: 'Driver {id} rated {rating} stars',
    log_points_redeemed: '75 points redeemed for a free order',
    log_commission_received: 'Commission of {amount} points received for order {id}.',
    log_region_updated: 'Region details updated: {name}',
    log_driver_updated: 'Driver details updated: {name} in {region}',
    log_theme_changed: 'Theme changed to {theme}',
    log_language_changed: 'Language changed to {lang}',
    add_region: 'Add New Region',
    add_driver: 'Add New Driver',
    edit_region: 'Edit Region',
    edit_driver: 'Edit Driver',
    region_name: 'Region Name',
    driver_name: 'Driver Name',
    rating: 'Rating',
    phone: 'Phone',
    save: 'Save',
    admin_account: 'Admin Account',
    no_orders: 'No orders available.',
    commission: 'Commission',
    accept_order: 'Accept Order',
    verified: 'Verified',
    upload_receipt: 'Upload Receipt',
    verify_ai: 'AI Verifying...',
    not_verified: 'Not Verified',
    confirm_payment: 'Confirm Payment',
    developed_by: 'App developed by Sky Gaza Tech Company',
    premium_benefits: 'Valuable gifts & discounts + Watch 8 premium ads daily',
    premium_payment_title: 'Subscribe to Premium',
    premium_payment_desc: 'Please transfer 18 NIS to wallet 0594840428 and attach a photo of the payment receipt',
    job_desc: 'Do you own a bicycle or electric bike? Are you credible and honest? Join us now as a delivery partner.',
    connection_status_label: 'Connection Status',
    available_orders: 'Available Orders',
    active_orders: 'Your Active Orders',
    chat_title: 'Chat',
    complete_order_btn: 'Complete Order',
    start_chat_msg: 'Start chat with {name}',
    try_hello_msg: 'Try sending "Hello"',
    sms_body: 'Hello, regarding order #{id}...',
    your_location_label: 'Your Location',
    driver_label: 'Driver',
    job_success: 'Applied successfully! Technical support will respond to you as soon as possible for acceptance.',
    contact_email_label: 'Contact Email',
    email_placeholder: 'example@mail.com',
    job_terms_email: 'Provide a valid email for communication.',
    no_logs: 'No logs recorded yet.',
    your_location: 'Your Location',
    driver_location: 'Driver Location',
    rate_msg: 'Thank you for your rating! Your feedback helps us improve.',
    free_order_redeemed: 'Congratulations! Your next free order is activated.',
    points_needed: 'You need more points for a free order.',
    preparing_order: 'Preparing Order',
    waiting_payment: 'Waiting Payment',
    accepted: 'Accepted',
    pending: 'Pending',
    apply_job: 'Join as a Driver',
    order_id: 'Order ID',
    customer: 'Customer',
    amount: 'Amount',
    status: 'Status',
    actions: 'Actions',
    job_application: 'Apply for Job Now',
    job_applications: 'Job Applications',
    follow_us: 'Follow all our accounts for prizes and discounts',
    city_address: 'Current Address (City)',
    delivery_experience: 'Do you have previous delivery experience?',
    experience_placeholder: 'e.g., Yes, 2 years in Gaza',
    welcome_title: 'Welcome to MOOV',
    welcome_subtitle: 'Fastest delivery service in Gaza',
    switch_account: 'Switch Account',
    my_points: 'My Points',
    id_number: 'ID Number',
    whatsapp: 'WhatsApp',
    facebook: 'Facebook',
    instagram: 'Instagram',
    enter_referral: 'Enter Referral Code',
    redeem: 'Redeem',
    referral_redeemed: 'Code redeemed! You received 5 points.',
    invalid_referral: 'Invalid code.',
    welcome_arabic: 'موڤ للتوصيل السريع',
    login_google: 'Login with Google',
    login_guest: 'Login as Guest',
    login_direct: 'Direct Login (Name/Email)',
    login_driver: 'Driver Login',
    back_to_login: 'Back to Login Page',
    name_label: 'Full Name',
    email_label: 'Email Address',
    guest_restriction: '⚠️ As a guest, you cannot receive gifts or discounts. Log in with email to enjoy all benefits.',
    notification_permission: 'Would you like to enable notifications for order updates and discounts?',
    allow: 'Allow',
    deny: 'Deny',
    new_discount_alert: 'New discounts are available now! Check your wallet.',
    login_success_alert: 'Logged in successfully! Welcome {name}.',
    order_placed_alert: 'Your order has been placed successfully! You will be notified when a driver accepts it.',
    referral_code: 'Referral Code (Optional)',
    referral_success: 'Referral code activated! Referrer received 1 point.',
    your_referral_code: 'Your Referral Code',
    premium_membership: 'Premium Membership',
    premium_desc: 'Get double points and exclusive discounts!',
    subscribe_premium: 'Subscribe Now',
    is_premium: 'You are a Premium Member 💎',
    referral_points_msg: 'Share your code and get 1 point for each friend who registers!',
    search_placeholder: 'Search for area or restaurant...',
    mailbox: 'Mailbox',
    mailbox_desc: 'Receive exclusive offers and important messages here',
    no_messages: 'No new messages at the moment',
    back_box: 'Back Box',
    chat_list_title: 'Chats',
    admin_password_required: 'Admin Password Required',
    enter_admin_password: 'Enter Admin Password',
    watch_ad: 'Watch Ad & Earn',
    ad_limit_reached: 'Daily limit reached (4 ads)',
    ad_reward_success: 'Congrats! You earned 0.5 points',
    live_tracking: 'Live Tracking',
    delay_discount_applied: 'Sorry for the delay! An automatic discount has been applied.',
    no_active_chats: 'No active chats',
    remember_me: 'Remember Me',
    ad_watched_today: 'Ads today: {count}/4',
    watch_ad_btn: 'Watch Ad to earn 0.5 points',
    discount_notice: 'Discount of {amount} points applied due to delay',
    refresh_rate: 'App Refresh Rate',
    refresh_rate_desc: 'Choose preferred refresh rate for your device (Hz)'
  }
};

const MoovLogo = () => (
  <div className="relative flex items-center gap-3">
    <div className="w-14 h-14 bg-moov-purple-neon rounded-xl flex flex-col items-center justify-center shadow-lg shadow-moov-purple/30 border-2 border-white/20 leading-none">
      <span className="text-white font-black text-xs tracking-tighter font-display">MOOV</span>
      <span className="text-moov-gold font-bold text-[7px] uppercase tracking-[0.2em] mt-0.5">Delivery</span>
    </div>
    <div className="flex flex-col">
      <span className="text-moov-yellow font-black text-sm drop-shadow-md">موڤ للتوصيل السريع</span>
    </div>
    <div className="absolute -right-4 -top-1 shimmer-gold opacity-30">
      <ArrowRight className="w-8 h-8 text-moov-yellow rotate-[-45deg] stroke-[3px]" />
    </div>
  </div>
);

export default function App() {
  const [regions, setRegions] = useState<Region[]>(() => {
    const saved = localStorage.getItem('moov_regions');
    return saved ? JSON.parse(saved) : INITIAL_REGIONS;
  });
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('moov_orders');
    return saved ? JSON.parse(saved) : MOCK_ORDERS;
  });
  const [view, setView] = useState<ViewState>('regions');
  const [selectedRegionId, setSelectedRegionId] = useState<string | null>(null);
  const [selectedDriverId, setSelectedDriverId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Record<string, ChatMessage[]>>({});
  
  // Modals
  const [isRegionModalOpen, setIsRegionModalOpen] = useState(false);
  const [editingRegion, setEditingRegion] = useState<Region | null>(null);
  const [isDriverModalOpen, setIsDriverModalOpen] = useState(false);
  const [editingDriver, setEditingDriver] = useState<Driver | null>(null);
  const [isJobModalOpen, setIsJobModalOpen] = useState(false);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isPremiumModalOpen, setIsPremiumModalOpen] = useState(false);
  const [receiptImage, setReceiptImage] = useState<string | null>(null);
  const [isDirectLoginOpen, setIsDirectLoginOpen] = useState(false);
  const [directLoginName, setDirectLoginName] = useState('');
  const [directLoginEmail, setDirectLoginEmail] = useState('');
  const [referralInput, setReferralInput] = useState('');
  const [jobForm, setJobForm] = useState({ name: '', id: '', experience: '' });
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
  const [isErrorModalOpen, setIsErrorModalOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [lastCreatedOrderId, setLastCreatedOrderId] = useState<string | null>(null);
  const [isOfflineMode, setIsOfflineMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [logs, setLogs] = useState<LogEntry[]>(() => {
    const saved = localStorage.getItem('moov_logs');
    return saved ? JSON.parse(saved) : [];
  });
  const [jobApplications, setJobApplications] = useState<JobApplication[]>(() => {
    const saved = localStorage.getItem('moov_job_apps');
    return saved ? JSON.parse(saved) : [];
  });
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [authenticatedDriver, setAuthenticatedDriver] = useState<Driver | null>(null);
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [showLoginError, setShowLoginError] = useState(false);
  const [loginErrorMessage, setLoginErrorMessage] = useState('');
  const [loginLockouts, setLoginLockouts] = useState<Record<string, { attempts: number, lockoutUntil: number | null }>>(() => {
    const saved = localStorage.getItem('moov_login_lockouts');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return {};
      }
    }
    return {};
  });

  useEffect(() => {
    localStorage.setItem('moov_regions', JSON.stringify(regions));
  }, [regions]);

  useEffect(() => {
    localStorage.setItem('moov_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('moov_logs', JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem('moov_job_apps', JSON.stringify(jobApplications));
  }, [jobApplications]);

  useEffect(() => {
    localStorage.setItem('moov_login_lockouts', JSON.stringify(loginLockouts));
  }, [loginLockouts]);

  useEffect(() => {
    setShowLoginError(false);
    setLoginErrorMessage('');
  }, [loginUsername, loginPassword]);

  const [isAdminPasswordModalOpen, setIsAdminPasswordModalOpen] = useState(false);
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [adminAction, setAdminAction] = useState<(() => void) | null>(null);

  const checkAdminPassword = (action: () => void) => {
    if (isAdminAuthenticated) {
      action();
    } else {
      setAdminAction(() => action);
      setIsAdminPasswordModalOpen(true);
    }
  };

  const handleAdminPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPasswordInput === ADMIN_CREDENTIALS.password) {
      if (adminAction) adminAction();
      setIsAdminPasswordModalOpen(false);
      setAdminPasswordInput('');
      setAdminAction(null);
    } else {
      alert(t.login_error);
    }
  };

  const handleWatchAd = () => {
    const today = new Date().toISOString().split('T')[0];
    const lastDate = userProfile.lastAdWatchDate;
    
    let dailyCount = userProfile.dailyAdsWatched || 0;
    if (lastDate !== today) {
      dailyCount = 0;
    }

    const limit = userProfile.isPremium ? 8 : 4;
    if (dailyCount >= limit) {
      alert(t.ad_limit_reached.replace('4', limit.toString()));
      return;
    }

    // Simulate ad watching
    setSuccessMessage(t.ad_reward_success);
    setIsSuccessModalOpen(true);

    setUserProfile(prev => ({
      ...prev,
      points: prev.points + 0.5,
      dailyAdsWatched: dailyCount + 1,
      lastAdWatchDate: today
    }));

    addLog('ad_reward', t.ad_reward_success, 0.5, { userId: userProfile.id });
  };

  // New State for Loyalty, Settings, and Tracking
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('moov_user_profile');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        return {
          ...data,
          dailyAdsWatched: data.dailyAdsWatched || 0,
          points: data.points || 0,
          ordersCount: data.ordersCount || 0
        };
      } catch (e) {
        // Fallback
      }
    }
    return {
      id: 'user_1',
      name: 'User',
      phone: '0590000000',
      points: 0,
      ordersCount: 0,
      isDarkTheme: true,
      language: 'ar',
      isGuest: false,
      isAuthenticated: false,
      referralCode: Math.random().toString(36).substring(2, 8).toUpperCase(),
      isPremium: false,
      dailyAdsWatched: 0,
      refreshRate: '60Hz'
    };
  });

  const [chatRooms, setChatRooms] = useState<ChatRoom[]>(() => {
    const saved = localStorage.getItem('moov_chat_rooms');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('moov_chat_rooms', JSON.stringify(chatRooms));
  }, [chatRooms]);

  useEffect(() => {
    localStorage.setItem('moov_user_profile', JSON.stringify(userProfile));
  }, [userProfile]);

  // Fetch real profile on login
  useEffect(() => {
    if (userProfile.isAuthenticated && !userProfile.isGuest) {
      const fetchProfile = async () => {
        try {
          const email = isAdminAuthenticated ? 'admin@app.com' : (authenticatedDriver?.email || userProfile.email || 'user@gmail.com');
          const res = await fetch(`/api/user/profile?email=${encodeURIComponent(email)}`);
          if (res.ok) {
            const data = await res.json();
            setUserProfile(prev => ({
              ...prev
            }));
          }
        } catch (err) {
          console.error("Failed to fetch profile:", err);
        }
      };
      fetchProfile();
    }
  }, [userProfile.isAuthenticated, userProfile.isGuest, isAdminAuthenticated, authenticatedDriver]);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isNotificationModalOpen, setIsNotificationModalOpen] = useState(false);
  const [selectedOrderIdForTracking, setSelectedOrderIdForTracking] = useState<string | null>(null);
  const [etaInput, setEtaInput] = useState('');
  const [trackingOrder, setTrackingOrder] = useState<Order | null>(null);

  const t = TRANSLATIONS[userProfile.language];

  // Driver Movement Simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setOrders(prev => prev.map(order => {
        if (order.status === 'delivering' && order.driverLocation && order.customerLocation) {
          const newLat = order.driverLocation.lat + (order.customerLocation.lat - order.driverLocation.lat) * 0.05;
          const newLng = order.driverLocation.lng + (order.customerLocation.lng - order.driverLocation.lng) * 0.05;
          return { ...order, driverLocation: { lat: newLat, lng: newLng } };
        }
        return order;
      }));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // OAuth Listener
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (!event.origin.endsWith('.run.app') && !event.origin.includes('localhost')) return;
      
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        const { user } = event.data;
        setUserProfile(prev => ({
          ...prev,
          name: user.name,
          email: user.email,
          isAuthenticated: true,
          isGuest: false
        }));
        setSuccessMessage(t.login_success_alert.replace('{name}', user.name));
        setIsSuccessModalOpen(true);
        setIsNotificationModalOpen(true);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [t]);

  const handleOAuthLogin = async (provider: 'google') => {
    try {
      const response = await fetch(`/api/auth/${provider}/url`);
      if (!response.ok) throw new Error('Failed to get auth URL');
      const { url } = await response.json();
      console.log('OAuth URL:', url);
      
      const authWindow = window.open(url, 'oauth_popup', 'width=600,height=700');
      if (!authWindow) {
        alert(userProfile.language === 'ar' ? 'يرجى السماح بالنوافذ المنبثقة لتسجيل الدخول' : 'Please allow popups to login');
      }
    } catch (error) {
      console.error('OAuth error:', error);
      alert(userProfile.language === 'ar' ? 'فشل الاتصال بخدمة تسجيل الدخول' : 'Failed to connect to login service');
    }
  };

  const handleGuestLogin = () => {
    setUserProfile(prev => ({
      ...prev,
      isAuthenticated: true,
      isGuest: true
    }));
    setIsNotificationModalOpen(true);
  };

  const handleDirectLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!directLoginName.trim() || !directLoginEmail.trim()) return;
    
    let initialPoints = 0;
    if (referralInput.trim()) {
      initialPoints = 1; // Award 1 point for using a referral code
      addLog('commission_received', t.referral_success, 1, { referralCode: referralInput });
    }

    setUserProfile(prev => ({
      ...prev,
      name: directLoginName,
      email: directLoginEmail,
      points: prev.points + initialPoints,
      isAuthenticated: true,
      isGuest: false,
      referredBy: referralInput.trim() || undefined
    }));
    setSuccessMessage(t.login_success_alert.replace('{name}', directLoginName));
    setIsSuccessModalOpen(true);
    setIsNotificationModalOpen(true);
    setIsDirectLoginOpen(false);
  };

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        new Notification('MOOV Delivery', {
          body: t.welcome_title,
          icon: '/favicon.ico'
        });
      }
    }
    setIsNotificationModalOpen(false);
  };

  const sendRealNotification = (title: string, body: string) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, { body });
    }
  };

  const ADMIN_CREDENTIALS = {
    username: 'mv101',
    password: 'moov101mvk101'
  };

  const addLog = (type: LogEntry['type'], message: string, amount?: number, details?: any) => {
    const newLog: LogEntry = {
      id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type,
      message,
      amount,
      timestamp: Date.now(),
      details
    };
    setLogs(prev => [newLog, ...prev]);
  };

  const handleAddOrder = (data: { customerName: string, regionName: string, details: string, price: number }) => {
    const newOrder: Order = {
      id: `order_${Date.now()}`,
      customerName: data.customerName,
      price: data.price,
      status: 'pending',
      regionName: data.regionName,
      timestamp: Date.now()
    };
    setOrders([...orders, newOrder]);
    setLastCreatedOrderId(newOrder.id);
    addLog('order_received', t.log_order_received.replace('{customer}', data.customerName).replace('{price}', data.price.toString()).replace('{region}', data.regionName), data.price, { orderId: newOrder.id });
    sendRealNotification('MOOV Delivery', t.order_placed_alert);
    setSuccessMessage(t.order_success_msg);
    setIsSuccessModalOpen(true);
  };

  useEffect(() => {
    const saved = localStorage.getItem('moov_remembered_user');
    if (saved) {
      const { username, password } = JSON.parse(saved);
      setLoginUsername(username);
      setLoginPassword(password);
      setRememberMe(true);
    }
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check Lockout
    const userLockout = loginLockouts[loginUsername];
    if (userLockout && userLockout.lockoutUntil && Date.now() < userLockout.lockoutUntil) {
      setLoginErrorMessage(t.login_error_lockout);
      setShowLoginError(true);
      return;
    }

    let loginSuccess = false;
    let authenticatedUser: Driver | { name: string } | null = null;

    // Check Admin
    if (loginUsername === ADMIN_CREDENTIALS.username && loginPassword === ADMIN_CREDENTIALS.password) {
      setIsAdminAuthenticated(true);
      setAuthenticatedDriver(null);
      setShowLoginError(false);
      setIsLoginModalOpen(false);
      setUserProfile(prev => ({ ...prev, points: 581, isAuthenticated: true, isGuest: false }));
      loginSuccess = true;
      authenticatedUser = { name: 'Admin' };
    } else {
      // Check Drivers
      for (const region of regions) {
        const driver = region.drivers.find(d => d.username === loginUsername && d.password === loginPassword);
        if (driver) {
          setAuthenticatedDriver(driver);
          setIsAdminAuthenticated(false);
          setSelectedRegionId(region.id);
          setSelectedDriverId(driver.id);
          setShowLoginError(false);
          setIsLoginModalOpen(false);
          setUserProfile(prev => ({ ...prev, isAuthenticated: true, isGuest: false, name: driver.name }));
          setView('regions'); // Redirect to cities/orders
          loginSuccess = true;
          authenticatedUser = driver;
          break;
        }
      }
    }

    if (loginSuccess) {
      if (rememberMe) {
        localStorage.setItem('moov_remembered_user', JSON.stringify({ username: loginUsername, password: loginPassword }));
      } else {
        localStorage.removeItem('moov_remembered_user');
      }
      // Reset lockout on success
      setLoginLockouts(prev => {
        const next = { ...prev };
        delete next[loginUsername];
        return next;
      });
      return;
    }

    // Handle Failure
    setLoginLockouts(prev => {
      const current = prev[loginUsername] || { attempts: 0, lockoutUntil: null };
      const nextAttempts = current.attempts + 1;
      const isLocked = nextAttempts >= 4;
      
      return {
        ...prev,
        [loginUsername]: {
          attempts: nextAttempts,
          lockoutUntil: isLocked ? Date.now() + 2 * 60 * 60 * 1000 : null
        }
      };
    });

    setLoginErrorMessage(t.login_error);
    setShowLoginError(true);
  };

  const handleLogout = () => {
    setIsAdminAuthenticated(false);
    setAuthenticatedDriver(null);
    setLoginUsername('');
    setLoginPassword('');
    setUserProfile(prev => ({
      ...prev,
      isAuthenticated: false,
      isGuest: false,
      points: 0,
      ordersCount: 0
    }));
    setView('regions');
  };

  const [deleteConfirmation, setDeleteConfirmation] = useState<{ type: 'region' | 'driver', id: string, name: string, parentId?: string } | null>(null);

  const selectedRegion = useMemo(() => 
    regions.find(r => r.id === selectedRegionId), [regions, selectedRegionId]);
  
  const selectedDriver = useMemo(() => 
    selectedRegion?.drivers.find(d => d.id === selectedDriverId), [selectedRegion, selectedDriverId]);

  const currentMessages = useMemo(() => 
    selectedDriverId ? (messages[selectedDriverId] || []) : [], [messages, selectedDriverId]);

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentMessages]);

  useEffect(() => {
    if (!userProfile.isDarkTheme) {
      document.body.classList.add('light-theme');
    } else {
      document.body.classList.remove('light-theme');
    }
  }, [userProfile.isDarkTheme]);

  // --- Handlers ---

  const handleConfirmDelete = () => {
    if (!deleteConfirmation) return;

    if (deleteConfirmation.type === 'region') {
      handleDeleteRegion(deleteConfirmation.id);
    } else if (deleteConfirmation.type === 'driver' && deleteConfirmation.parentId) {
      handleDeleteDriver(deleteConfirmation.parentId, deleteConfirmation.id);
    }
    setDeleteConfirmation(null);
  };

  const handleAddRegion = (name: string) => {
    if (!isAdminAuthenticated) {
      setErrorMessage(t.admin_only);
      setIsErrorModalOpen(true);
      return;
    }
    const newRegion: Region = {
      id: Date.now().toString(),
      name,
      drivers: []
    };
    setRegions([...regions, newRegion]);
    addLog('commission_received', t.log_region_added.replace('{name}', name), undefined, { regionId: newRegion.id });
  };

  const handleUpdateRegion = (id: string, name: string) => {
    if (!isAdminAuthenticated) {
      setErrorMessage(t.admin_only);
      setIsErrorModalOpen(true);
      return;
    }
    setRegions(regions.map(r => r.id === id ? { ...r, name } : r));
    addLog('commission_received', t.log_region_updated.replace('{name}', name), undefined, { regionId: id, name });
  };

  const handleDeleteRegion = (id: string) => {
    if (!isAdminAuthenticated) {
      setErrorMessage(t.admin_only);
      setIsErrorModalOpen(true);
      return;
    }
    setRegions(regions.filter(r => r.id !== id));
    addLog('commission_received', t.log_region_deleted.replace('{id}', id), undefined, { regionId: id });
    if (selectedRegionId === id) {
      setView('regions');
      setSelectedRegionId(null);
    }
  };

  const handleAddDriver = (regionId: string, name: string, rating: number, phone: string, username?: string, password?: string) => {
    if (!isAdminAuthenticated) {
      setErrorMessage(t.admin_only);
      setIsErrorModalOpen(true);
      return;
    }
    const driverId = Date.now().toString();
    setRegions(regions.map(r => {
      if (r.id === regionId) {
        return {
          ...r,
          drivers: [...r.drivers, { id: driverId, name, rating, phone, username, password }]
        };
      }
      return r;
    }));
    addLog('commission_received', t.log_driver_added.replace('{name}', name).replace('{region}', regionId), undefined, { driverId, regionId });
  };

  const handleUpdateDriver = (regionId: string, driverId: string, name: string, rating: number, phone: string, username?: string, password?: string) => {
    if (!isAdminAuthenticated) {
      setErrorMessage(t.admin_only);
      setIsErrorModalOpen(true);
      return;
    }
    setRegions(regions.map(r => {
      if (r.id === regionId) {
        return {
          ...r,
          drivers: r.drivers.map(d => d.id === driverId ? { ...d, name, rating, phone, username, password } : d)
        };
      }
      return r;
    }));
    addLog('commission_received', t.log_driver_updated.replace('{name}', name).replace('{region}', regionId), undefined, { driverId, regionId, name, phone, username, password });
  };

  const handleDeleteDriver = (regionId: string, driverId: string) => {
    if (!isAdminAuthenticated) {
      setErrorMessage(t.admin_only);
      setIsErrorModalOpen(true);
      return;
    }
    setRegions(regions.map(r => {
      if (r.id === regionId) {
        return {
          ...r,
          drivers: r.drivers.filter(d => d.id !== driverId)
        };
      }
      return r;
    }));
    addLog('commission_received', t.log_driver_deleted.replace('{id}', driverId).replace('{region}', regionId), undefined, { driverId, regionId });
    if (selectedDriverId === driverId) {
      setView('drivers');
      setSelectedDriverId(null);
    }
  };

  const handleAcceptOrder = (order: Order) => {
    if (!selectedDriver) return;
    
    setOrders(prev => prev.map(o => o.id === order.id ? { 
      ...o, 
      status: 'accepted',
      driverLocation: { lat: 31.4175, lng: 34.3509 }, // Initial driver location
      customerLocation: { lat: 31.4275, lng: 34.3609 } // Initial customer location
    } : o));
    addLog('order_received', `Driver ${selectedDriver.name} accepted order ${order.id}`, undefined, { driverId: selectedDriver.id, orderId: order.id });
    setSuccessMessage(t.success);
    setIsSuccessModalOpen(true);
  };

  const handleCompleteOrder = (orderId: string) => {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'completed' } : o));
    
    // Update customer loyalty
    setUserProfile(prev => {
      if (prev.isGuest) return prev; // Guests don't get points
      const newOrdersCount = prev.ordersCount + 1;
      const newPoints = prev.points + 1;
      
      // Apply discount after 5 orders (simulated as a log/notification)
      if (newOrdersCount % 5 === 0) {
        addLog('commission_received', t.log_loyalty_discount.replace('{count}', newOrdersCount.toString()), undefined, { userId: prev.id });
      }
      
      return {
        ...prev,
        ordersCount: newOrdersCount,
        points: newPoints
      };
    });

    // Log the completion and the money received by the driver
    addLog('order_completed', t.log_order_completed.replace('{id}', orderId), order.price, { orderId, customerName: order.customerName });
    
    // Delay Policy Check
    if (order.eta) {
      const etaMinutes = parseInt(order.eta);
      const elapsedMinutes = (Date.now() - order.timestamp) / (1000 * 60);
      if (elapsedMinutes > etaMinutes + 10) { // 10 minutes grace period
        setUserProfile(prev => ({ ...prev, points: prev.points + 5 })); // 5 points compensation
        addLog('commission_received', t.delay_discount_applied, 5, { orderId });
        setSuccessMessage(t.delay_discount_applied);
        setIsSuccessModalOpen(true);
      }
    }

    sendRealNotification('MOOV Delivery', t.order_completed_success.replace('{price}', order.price.toString()));
    setSuccessMessage(t.order_completed_success.replace('{price}', order.price.toString()));
    setIsSuccessModalOpen(true);
  };

  const handleUpdateOrderStatus = (orderId: string, status: Order['status'], eta?: string) => {
    setOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        let etaTimestamp = o.etaTimestamp;
        let discountApplied = o.discountApplied;
        
        // If status is moving to completed, check if ETA was exceeded
        if (status === 'completed' && etaTimestamp && Date.now() > etaTimestamp && !discountApplied) {
          discountApplied = true;
          // Apply 20% discount if delayed
          const discountAmount = Math.floor(o.price * 0.2);
          const newPrice = o.price - discountAmount;
          
          addLog('commission_received', t.discount_notice.replace('{amount}', discountAmount.toString()), undefined, { orderId });
          sendRealNotification('MOOV Delivery', t.delay_discount_applied);
          
          return { ...o, status, discountApplied, price: newPrice };
        }

        // If ETA is being set for the first time or updated
        if (eta) {
          // Parse ETA string like "15 mins" or "15"
          const mins = parseInt(eta.replace(/[^0-9]/g, '')) || 15;
          etaTimestamp = Date.now() + (mins * 60 * 1000);
        }

        return { ...o, status, eta: eta || o.eta, etaTimestamp };
      }
      return o;
    }));
    addLog('commission_received', t.log_status_updated.replace('{id}', orderId).replace('{status}', status), undefined, { orderId, status });
  };

  const handleRateDriver = (driverId: string, rating: number) => {
    setRegions(prev => prev.map(r => ({
      ...r,
      drivers: r.drivers.map(d => {
        if (d.id === driverId) {
          const newCount = d.ratingCount + 1;
          const newRating = ((d.rating * d.ratingCount) + rating) / newCount;
          return { ...d, rating: Number(newRating.toFixed(1)), ratingCount: newCount };
        }
        return d;
      })
    })));
    addLog('rating_received', t.log_rating_received.replace('{id}', driverId).replace('{rating}', rating.toString()), undefined, { driverId, rating });
    setSuccessMessage(t.rate_msg);
    setIsSuccessModalOpen(true);
  };

  const handleRedeemPoints = () => {
    if (userProfile.points >= 75) { // 15 orders * 5 points = 75 points for a free order
      setUserProfile(prev => ({ ...prev, points: prev.points - 75 }));
      addLog('points_redeemed', t.log_points_redeemed, undefined, { userId: userProfile.id });
      setSuccessMessage(t.free_order_redeemed);
      setIsSuccessModalOpen(true);
    } else {
      alert(t.points_needed);
    }
  };

  const toggleTheme = () => {
    setUserProfile(prev => {
      const newTheme = !prev.isDarkTheme;
      addLog('commission_received', t.log_theme_changed.replace('{theme}', newTheme ? t.dark : t.light), undefined, { isDarkTheme: newTheme });
      return { ...prev, isDarkTheme: newTheme };
    });
  };

  const toggleLanguage = () => {
    setUserProfile(prev => {
      const newLang = prev.language === 'ar' ? 'en' : 'ar';
      // Note: we use the current 't' because the language hasn't switched in the state yet for this render cycle's 't'
      addLog('commission_received', t.log_language_changed.replace('{lang}', newLang === 'ar' ? 'العربية' : 'English'), undefined, { language: newLang });
      return { ...prev, language: newLang };
    });
  };

  const sendMessage = (text: string) => {
    if (!selectedDriverId || !text.trim()) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      text: text.trim(),
      isUserMessage: true,
      timestamp: Date.now()
    };

    setMessages(prev => ({
      ...prev,
      [selectedDriverId]: [...(prev[selectedDriverId] || []), newMessage]
    }));

    // Update Chat Rooms
    setChatRooms(prev => {
      const existing = prev.find(r => r.driverId === selectedDriverId && r.customerId === userProfile.id);
      if (existing) {
        return prev.map(r => r.id === existing.id ? {
          ...r,
          lastMessage: text.trim(),
          lastMessageTime: Date.now(),
          unreadCount: authenticatedDriver ? r.unreadCount + 1 : 0
        } : r);
      } else {
        return [...prev, {
          id: `room_${Date.now()}`,
          customerId: userProfile.id,
          customerName: userProfile.name,
          driverId: selectedDriverId,
          lastMessage: text.trim(),
          lastMessageTime: Date.now(),
          unreadCount: authenticatedDriver ? 1 : 0
        }];
      }
    });

    if (text.trim() === (userProfile.language === 'ar' ? "مرحبا" : "Hello")) {
      setTimeout(() => {
        const reply: ChatMessage = {
          id: (Date.now() + 1).toString(),
          text: t.chat_welcome.replace('{name}', selectedDriver?.name || (userProfile.language === 'ar' ? 'السائق' : 'Driver')),
          isUserMessage: false,
          timestamp: Date.now()
        };
        setMessages(prev => ({
          ...prev,
          [selectedDriverId]: [...(prev[selectedDriverId] || []), reply]
        }));
      }, 1000);
    }
  };

  // --- UI Components ---

  const CustomerTrackingView = ({ order }: { order: Order }) => {
    const driver = regions.flatMap(r => r.drivers).find(d => d.id === selectedDriverId);
    const [driverPos, setDriverPos] = useState<[number, number]>([31.4175, 34.3509]);
    const customerPos: [number, number] = [31.4160, 34.3480];

    // Simulate driver movement if delivering
    useEffect(() => {
      if (order.status === 'delivering') {
        const interval = setInterval(() => {
          setDriverPos(prev => [
            prev[0] + (Math.random() - 0.5) * 0.001,
            prev[1] + (Math.random() - 0.5) * 0.001
          ]);
        }, 3000);
        return () => clearInterval(interval);
      }
    }, [order.status]);
    
    return (
      <div className="space-y-6 pb-20">
        {/* Status Stepper */}
        <div className={`p-6 rounded-[2.5rem] ${userProfile.isDarkTheme ? 'bg-zinc-900' : 'bg-white shadow-xl'}`}>
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-xl font-black font-display">{t.tracking}</h3>
            <div className="flex items-center gap-2 text-moov-gold">
              <Clock className="w-4 h-4" />
              <span className="text-sm font-black">{order.eta || '--:--'}</span>
            </div>
          </div>

          <div className="relative flex justify-between items-start">
            <div className="absolute top-4 left-0 right-0 h-0.5 bg-zinc-800 z-0" />
            <div 
              className="absolute top-4 left-0 h-0.5 bg-moov-gold z-0 transition-all duration-1000" 
              style={{ 
                width: order.status === 'preparing' ? '33%' : 
                       order.status === 'delivering' ? '66%' : 
                       order.status === 'arriving' ? '90%' : 
                       order.status === 'completed' ? '100%' : '0%' 
              }} 
            />
            
            {[
              { id: 'preparing', icon: ShoppingBag, label: t.preparing },
              { id: 'delivering', icon: Navigation, label: t.delivering },
              { id: 'arriving', icon: MapPin, label: t.arriving },
              { id: 'completed', icon: CheckCircle2, label: t.completed }
            ].map((step, idx) => {
              const isActive = order.status === step.id || (idx === 0 && order.status === 'accepted');
              const isPast = ['preparing', 'delivering', 'arriving', 'completed'].indexOf(order.status) >= idx;
              
              return (
                <div key={step.id} className="relative z-10 flex flex-col items-center gap-2">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-500 ${isPast ? 'bg-moov-gold border-moov-gold text-black' : 'bg-zinc-900 border-zinc-800 text-zinc-600'}`}>
                    <step.icon className="w-5 h-5" />
                  </div>
                  <span className={`text-[10px] font-black text-center max-w-[60px] ${isPast ? 'text-moov-gold' : 'text-zinc-600'}`}>{step.label}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Live Map */}
        <div className={`h-80 rounded-[2.5rem] relative overflow-hidden border-2 ${userProfile.isDarkTheme ? 'bg-zinc-900 border-white/5' : 'bg-zinc-100 border-black/5'}`}>
          <MapContainer center={driverPos} zoom={15} scrollWheelZoom={false} className="h-full w-full">
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url={userProfile.isDarkTheme 
                ? "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                : "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              }
            />
            <Marker position={driverPos} icon={DriverIcon}>
              <Popup>
                {driver?.name || t.driver_label}
              </Popup>
            </Marker>
            <Marker position={customerPos} icon={CustomerIcon}>
              <Popup>
                {t.your_location_label}
              </Popup>
            </Marker>
            <MapUpdater center={driverPos} />
          </MapContainer>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-3">
          <button 
            onClick={() => window.open(`sms:${driver?.phone}?body=${t.sms_body.replace('{id}', order.id)}`, '_blank')}
            className={`flex items-center justify-center gap-2 p-5 rounded-3xl font-black transition-all active:scale-95 ${userProfile.isDarkTheme ? 'bg-white/5 text-white hover:bg-white/10' : 'bg-zinc-100 text-zinc-900 hover:bg-zinc-200'}`}
          >
            <Phone className="w-5 h-5 text-emerald-500" />
            {t.contact_driver}
          </button>
          <button 
            onClick={() => window.open('https://wa.me/970567276125', '_blank')}
            className={`flex items-center justify-center gap-2 p-5 rounded-3xl font-black transition-all active:scale-95 ${userProfile.isDarkTheme ? 'bg-white/5 text-white hover:bg-white/10' : 'bg-zinc-100 text-zinc-900 hover:bg-zinc-200'}`}
          >
            <Mail className="w-5 h-5 text-moov-gold" />
            {t.contact_admin}
          </button>
        </div>

        {/* Rating Section */}
        {order.status === 'completed' && !order.rating && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-8 rounded-[2.5rem] text-center space-y-6 ${userProfile.isDarkTheme ? 'bg-moov-gold/10 border-2 border-moov-gold/30' : 'bg-white shadow-xl border-2 border-moov-gold/20'}`}
          >
            <ThumbsUp className="w-12 h-12 text-moov-gold mx-auto" />
            <h4 className="text-xl font-black font-display">{t.rate_driver}</h4>
            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4, 5].map(star => (
                <button 
                  key={star}
                  onClick={() => handleRateDriver(driver?.id || '', star)}
                  className="p-2 hover:scale-125 transition-transform"
                >
                  <Star className={`w-8 h-8 ${star <= (order.rating || 0) ? 'fill-moov-gold text-moov-gold' : 'text-zinc-600'}`} />
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    );
  };

  const Header = () => (
    <header className={`sticky top-0 z-30 border-b px-4 py-4 flex items-center justify-between shadow-lg transition-colors duration-300 gpu-accelerated ${userProfile.isDarkTheme ? 'bg-black/40 backdrop-blur-xl border-moov-gold/30' : 'bg-white/80 backdrop-blur-xl border-moov-purple/10'}`}>
      <div className="flex items-center gap-4">
        {view !== 'regions' ? (
          <button 
            onClick={() => {
              if (view === 'chat') setView('drivers');
              else if (view === 'customer_view') setView('regions');
              else setView('regions');
            }}
            className={`p-2 rounded-full transition-colors ${userProfile.isDarkTheme ? 'hover:bg-white/10 text-moov-gold' : 'hover:bg-black/5 text-moov-purple'}`}
          >
            <ChevronLeft className="w-6 h-6 stroke-[3px]" />
          </button>
        ) : (
          <MoovLogo />
        )}
        <h1 className={`text-xl font-black font-display drop-shadow-sm ${userProfile.isDarkTheme ? 'text-moov-gold' : 'text-moov-purple'}`}>
          {view === 'regions' && "MOOV"}
          {view === 'drivers' && selectedRegion?.name}
          {view === 'chat' && selectedDriver?.name}
          {view === 'customer_view' && t.tracking}
          {view === 'settings' && t.settings}
        </h1>
      </div>
      <div className="flex items-center gap-2">
        <button 
          onClick={() => setIsSettingsOpen(true)}
          className={`flex flex-col items-center justify-center p-2 rounded-2xl transition-all active:scale-90 ${userProfile.isDarkTheme ? 'bg-white/5 text-moov-gold' : 'bg-black/5 text-moov-purple'}`}
        >
          <Settings className="w-6 h-6" />
          <span className="text-[8px] font-black uppercase mt-1">{t.settings}</span>
        </button>
        
        {view === 'regions' && !isAdminAuthenticated && !authenticatedDriver && (
          <button 
            onClick={() => setIsOrderModalOpen(true)}
            className="flex items-center gap-1.5 bg-moov-gold text-black px-3 py-1.5 rounded-full font-black text-[10px] shadow-lg shadow-moov-gold/30 active:scale-95 transition-all"
          >
            <Plus className="w-3 h-3 stroke-[4px]" />
            {t.new_order_title}
          </button>
        )}
        {view === 'drivers' && selectedDriverId && (isAdminAuthenticated || (authenticatedDriver && authenticatedDriver.id === selectedDriverId)) && (
          <button 
            onClick={() => setView('orders')}
            className="p-2 bg-moov-purple-neon/20 hover:bg-moov-purple-neon/30 rounded-full transition-all text-moov-purple-neon"
          >
            <ShoppingBag className="w-5 h-5" />
          </button>
        )}
        {view === 'regions' && isAdminAuthenticated && (
          <button 
            onClick={() => { setEditingRegion(null); setIsRegionModalOpen(true); }}
            className="p-2 bg-moov-gold hover:bg-yellow-400 rounded-full transition-all shadow-lg shadow-moov-gold/40 active:scale-90"
          >
            <Plus className="w-5 h-5 text-black stroke-[3px]" />
          </button>
        )}
        {view === 'drivers' && isAdminAuthenticated && (
          <button 
            onClick={() => { setEditingDriver(null); setIsDriverModalOpen(true); }}
            className="p-2 bg-moov-gold hover:bg-yellow-400 rounded-full transition-all shadow-lg shadow-moov-gold/40 active:scale-90"
          >
            <Plus className="w-5 h-5 text-black stroke-[3px]" />
          </button>
        )}
      </div>
    </header>
  );

  const handleRedeemReferral = () => {
    if (referralInput.trim().length > 3) {
      setUserProfile(prev => ({ ...prev, points: prev.points + 5 }));
      setSuccessMessage(t.referral_redeemed);
      setIsSuccessModalOpen(true);
      setReferralInput('');
    } else {
      setLoginErrorMessage(t.invalid_referral);
      setShowLoginError(true);
    }
  };

  const handleJobSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (jobForm.name && jobForm.id && jobForm.experience) {
      const newApp: JobApplication = {
        id: `app_${Date.now()}`,
        name: jobForm.name,
        email: userProfile.email || 'N/A',
        city: 'N/A',
        age: '0',
        dob: 'N/A',
        experience: jobForm.experience,
        timestamp: Date.now()
      };
      setJobApplications(prev => [...prev, newApp]);
      setSuccessMessage(t.job_received_alert);
      setIsSuccessModalOpen(true);
      setJobForm({ name: '', id: '', experience: '' });
    }
  };

  const SettingsModal = () => (
    <AnimatePresence>
      {isSettingsOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSettingsOpen(false)}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            className={`relative w-full max-w-md rounded-t-[2.5rem] sm:rounded-[2.5rem] shadow-2xl flex flex-col max-h-[85vh] ${userProfile.isDarkTheme ? 'bg-zinc-900 text-white' : 'bg-white text-zinc-900'}`}
          >
            <div className="p-8 pb-4 border-b border-white/5 flex justify-between items-center shrink-0">
              <h3 className="text-2xl font-black font-display">{t.settings}</h3>
              <button onClick={() => setIsSettingsOpen(false)} className="p-2 hover:bg-black/5 rounded-full transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-8 pt-4 overflow-y-auto custom-scrollbar space-y-8">
              <div className="grid grid-cols-2 gap-3 opacity-80 scale-95">
                {/* My Points */}
                <button 
                  className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-white/5 hover:bg-white/10 transition-all active:scale-95 border border-white/5"
                >
                  <div className="w-10 h-10 bg-emerald-500/20 rounded-xl flex items-center justify-center relative">
                    <Wallet className="w-5 h-5 text-emerald-500" />
                    <div className="absolute -top-1 -right-1 bg-emerald-500 text-white text-[6px] font-black px-1 rounded-full">{userProfile.points}</div>
                  </div>
                  <span className="text-[8px] font-black uppercase tracking-wider">{t.my_points}</span>
                </button>

                {/* Language Toggle */}
                <button 
                  onClick={toggleLanguage}
                  className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-white/5 hover:bg-white/10 transition-all active:scale-95 border border-white/5"
                >
                  <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
                    <Globe className="w-5 h-5 text-blue-500" />
                  </div>
                  <span className="text-[8px] font-black uppercase tracking-wider">{t.language}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3 opacity-80 scale-95">
                {/* Theme Toggle */}
                <button 
                  onClick={toggleTheme}
                  className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-white/5 hover:bg-white/10 transition-all active:scale-95 border border-white/5"
                >
                  <div className="w-10 h-10 bg-amber-500/20 rounded-xl flex items-center justify-center">
                    {userProfile.isDarkTheme ? <Moon className="w-5 h-5 text-amber-500" /> : <Sun className="w-5 h-5 text-amber-500" />}
                  </div>
                  <span className="text-[8px] font-black uppercase tracking-wider">{t.theme}</span>
                </button>

                {/* Complaints Email */}
                <a 
                  href="mailto:ahmdbusiness101@gmail.com"
                  className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-white/5 hover:bg-white/10 transition-all active:scale-95 border border-white/5"
                >
                  <div className="w-10 h-10 bg-red-500/20 rounded-xl flex items-center justify-center">
                    <Mail className="w-5 h-5 text-red-500" />
                  </div>
                  <span className="text-[8px] font-black uppercase tracking-wider">{t.complaints}</span>
                </a>
              </div>

              {/* Watch Ad Reward */}
              <button 
                onClick={handleWatchAd}
                className="w-full flex items-center justify-between p-4 rounded-2xl bg-moov-gold/10 hover:bg-moov-gold/20 transition-all active:scale-95 border border-moov-gold/20 group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-moov-gold rounded-xl flex items-center justify-center text-black shadow-lg shadow-moov-gold/20">
                    <PlayCircle className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <h4 className="text-[10px] font-black uppercase tracking-wider text-moov-gold">{t.watch_ad}</h4>
                    <p className="text-[8px] text-white/40 font-bold">{t.ad_watched_today.replace('{count}', (userProfile.dailyAdsWatched || 0).toString())}</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-moov-gold group-hover:translate-x-1 transition-transform" />
              </button>

              {/* Premium Section */}
              <div className={`p-5 rounded-[1.5rem] border-2 transition-all opacity-80 scale-95 ${userProfile.isPremium ? 'bg-moov-gold/10 border-moov-gold shadow-[0_0_20px_rgba(255,215,0,0.2)]' : 'bg-white/5 border-white/10'}`}>
                <div className="flex items-center gap-3 mb-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${userProfile.isPremium ? 'bg-moov-gold text-black' : 'bg-zinc-800 text-moov-gold'}`}>
                    <Star className="w-5 h-5 fill-current" />
                  </div>
                  <div>
                    <h4 className="font-black text-xs">{userProfile.isPremium ? t.is_premium : t.premium_membership}</h4>
                    <p className="text-[8px] text-white/40 font-bold">{userProfile.isPremium ? t.premium_benefits : t.premium_desc}</p>
                  </div>
                </div>
                {!userProfile.isPremium && (
                  <button 
                    onClick={() => setIsPremiumModalOpen(true)}
                    className="w-full py-2 bg-moov-gold text-black font-black rounded-xl text-[10px] active:scale-95 transition-all"
                  >
                    {t.subscribe_premium}
                  </button>
                )}
              </div>

              {/* Refresh Rate Selection */}
              <div className="p-5 rounded-[1.5rem] bg-white/5 border border-white/10 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-moov-purple-neon/20 rounded-xl flex items-center justify-center">
                    <Clock className="w-5 h-5 text-moov-purple-neon" />
                  </div>
                  <div>
                    <h4 className="font-black text-xs">{t.refresh_rate}</h4>
                    <p className="text-[8px] text-white/40 font-bold">{t.refresh_rate_desc}</p>
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {(['60Hz', '90Hz', '120Hz', '144Hz'] as const).map((rate) => (
                    <button
                      key={rate}
                      onClick={() => setUserProfile(prev => ({ ...prev, refreshRate: rate }))}
                      className={`py-2 rounded-xl text-[10px] font-black transition-all ${userProfile.refreshRate === rate ? 'bg-moov-gold text-black shadow-lg shadow-moov-gold/20' : 'bg-white/5 text-white/40 hover:bg-white/10'}`}
                    >
                      {rate}
                    </button>
                  ))}
                </div>
              </div>

              {/* Mailbox Section */}
              <div className="p-8 rounded-[2.5rem] bg-gradient-to-br from-moov-purple via-moov-purple/40 to-moov-gold/30 border-2 border-moov-gold/50 space-y-6 shadow-[0_0_30px_rgba(168,85,247,0.3)] relative overflow-hidden group transform hover:scale-[1.02] transition-all duration-500">
                <div className="absolute -top-4 -right-4 p-4 opacity-10 group-hover:opacity-30 transition-all duration-700 rotate-12">
                  <Mail className="w-32 h-32" />
                </div>
                <div className="flex items-center gap-5 relative z-10">
                  <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-3xl flex items-center justify-center text-white border-2 border-white/30 shadow-inner">
                    <Mail className="w-8 h-8 animate-pulse" />
                  </div>
                  <div>
                    <h4 className="font-black text-xl text-white drop-shadow-md">{t.mailbox}</h4>
                    <p className="text-xs text-white/60 font-bold leading-tight">{t.mailbox_desc}</p>
                  </div>
                </div>
                <div className="bg-black/40 backdrop-blur-xl p-8 rounded-3xl border-2 border-dashed border-white/10 text-center relative z-10">
                  <p className="text-sm text-white/40 font-black italic tracking-wide">{t.no_messages}</p>
                </div>
                <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-moov-gold to-transparent opacity-50" />
              </div>

              {/* Referral Section */}
              <div className="p-6 rounded-[2rem] bg-moov-purple/10 border-2 border-moov-purple/30 space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-moov-purple rounded-2xl flex items-center justify-center text-white">
                    <Gift className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-black text-sm">{t.your_referral_code}</h4>
                    <p className="text-[10px] text-white/40 font-bold">{t.referral_points_msg}</p>
                  </div>
                </div>
                <div className="bg-black/40 p-4 rounded-2xl border border-white/10 flex items-center justify-between">
                  <span className="text-xl font-black text-moov-purple-neon tracking-widest">{userProfile.referralCode}</span>
                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(userProfile.referralCode);
                      setSuccessMessage(t.success);
                      setIsSuccessModalOpen(true);
                    }}
                    className="text-[10px] font-black text-moov-gold uppercase"
                  >
                    Copy
                  </button>
                </div>
                <div className="flex gap-2">
                  <input 
                    type="text"
                    placeholder={t.enter_referral}
                    value={referralInput}
                    onChange={(e) => setReferralInput(e.target.value)}
                    className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-xs font-bold focus:outline-none focus:border-moov-gold/50"
                  />
                  <button 
                    onClick={handleRedeemReferral}
                    className="bg-moov-gold text-black px-4 py-2 rounded-xl font-black text-[10px] active:scale-95 transition-all"
                  >
                    {t.redeem}
                  </button>
                </div>
              </div>

              {/* Support Section */}
              <div className="space-y-6">
                <div className="grid grid-cols-3 gap-3">
                  <button 
                    onClick={() => window.open('https://wa.me/970567276125', '_blank')}
                    className="flex flex-col items-center gap-2 p-4 rounded-3xl bg-emerald-500/10 border border-emerald-500/20 hover:bg-emerald-500/20 transition-all"
                  >
                    <div className="w-10 h-10 bg-emerald-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-emerald-500/30">
                      <Phone className="w-5 h-5" />
                    </div>
                    <span className="text-[8px] font-black uppercase text-emerald-500">{t.whatsapp}</span>
                  </button>
                  <button 
                    onClick={() => window.open('https://facebook.com/moov', '_blank')}
                    className="flex flex-col items-center gap-2 p-4 rounded-3xl bg-blue-600/10 border border-blue-600/20 hover:bg-blue-600/20 transition-all"
                  >
                    <div className="w-10 h-10 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-blue-600/30">
                      <Twitter className="w-5 h-5" />
                    </div>
                    <span className="text-[8px] font-black uppercase text-blue-600">{t.facebook}</span>
                  </button>
                  <button 
                    onClick={() => window.open('https://instagram.com/moov', '_blank')}
                    className="flex flex-col items-center gap-2 p-4 rounded-3xl bg-pink-500/10 border border-pink-500/20 hover:bg-pink-500/20 transition-all"
                  >
                    <div className="w-10 h-10 bg-pink-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-pink-500/30">
                      <Instagram className="w-5 h-5" />
                    </div>
                    <span className="text-[8px] font-black uppercase text-pink-500">{t.instagram}</span>
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );

  const PremiumModal = () => (
    <AnimatePresence>
      {isPremiumModalOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsPremiumModalOpen(false)}
            className="absolute inset-0 bg-black/90 backdrop-blur-xl"
          />
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={springTransition}
            className={`relative w-full max-w-sm rounded-[3rem] p-8 text-center space-y-6 shadow-2xl border-2 ${userProfile.isDarkTheme ? 'bg-zinc-900 border-moov-gold/30' : 'bg-white border-moov-purple/10'}`}
          >
            <div className="w-20 h-20 bg-moov-gold/20 rounded-3xl flex items-center justify-center mx-auto border-2 border-moov-gold/30 rotate-12">
              <Star className="w-10 h-10 text-moov-gold fill-current" />
            </div>
            
            <div className="space-y-2">
              <h3 className="text-2xl font-black font-display text-moov-gold">{t.premium_payment_title}</h3>
              <div className="bg-moov-gold/10 py-3 px-4 rounded-2xl border border-moov-gold/20">
                <p className="text-[10px] font-black text-moov-gold uppercase tracking-wider mb-1">المميزات</p>
                <p className="text-xs font-bold text-white/80">
                  {t.premium_benefits}
                </p>
              </div>
              <p className={`text-sm font-bold leading-relaxed pt-4 ${userProfile.isDarkTheme ? 'text-white/70' : 'text-zinc-600'}`}>
                {t.premium_payment_desc}
              </p>
            </div>

            <div className="space-y-4">
              <div className="relative group">
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onloadend = () => setReceiptImage(reader.result as string);
                      reader.readAsDataURL(file);
                    }
                  }}
                  className="hidden" 
                  id="receipt-upload" 
                />
                <label 
                  htmlFor="receipt-upload"
                  className={`flex flex-col items-center justify-center gap-3 p-6 rounded-3xl border-2 border-dashed transition-all cursor-pointer ${receiptImage ? 'border-green-500/50 bg-green-500/5' : 'border-moov-gold/30 hover:border-moov-gold bg-white/5'}`}
                >
                  {receiptImage ? (
                    <div className="relative w-full aspect-video rounded-xl overflow-hidden">
                      <img src={receiptImage} alt="Receipt" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <CheckCircle2 className="w-8 h-8 text-green-500" />
                      </div>
                    </div>
                  ) : (
                    <>
                      <Camera className="w-8 h-8 text-moov-gold" />
                      <span className="text-[10px] font-black uppercase tracking-widest text-moov-gold">{t.upload_receipt}</span>
                    </>
                  )}
                </label>
              </div>

              <button 
                disabled={!receiptImage}
                onClick={() => {
                  setSuccessMessage('تم إرسال طلب الاشتراك! سيتم تفعيل العضوية بعد مراجعة الإشعار.');
                  setIsSuccessModalOpen(true);
                  setIsPremiumModalOpen(false);
                  setTimeout(() => {
                    setUserProfile(prev => ({ ...prev, isPremium: true }));
                    addLog('order_received', 'تم تفعيل عضوية Premium بنجاح!', undefined, { type: 'premium_activation' });
                  }, 3000);
                }}
                className={`w-full py-5 font-black rounded-3xl shadow-xl transition-all active:scale-95 ${receiptImage ? 'bg-moov-gold text-black shadow-moov-gold/30' : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'}`}
              >
                {t.confirm_payment}
              </button>
              
              <button 
                onClick={() => setIsPremiumModalOpen(false)}
                className={`w-full py-2 font-black text-[10px] uppercase tracking-widest ${userProfile.isDarkTheme ? 'text-white/30 hover:text-white' : 'text-zinc-400 hover:text-zinc-900'}`}
              >
                {t.cancel}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );

  const NotificationModal = () => (
    <AnimatePresence>
      {isNotificationModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/80 backdrop-blur-md"
          />
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className={`relative w-full max-w-sm rounded-[3rem] p-10 text-center space-y-8 shadow-2xl border-2 ${userProfile.isDarkTheme ? 'bg-zinc-900 border-moov-gold/30' : 'bg-white border-moov-purple/10'}`}
          >
            <div className="w-24 h-24 bg-moov-gold/20 rounded-full flex items-center justify-center mx-auto border-2 border-moov-gold/30 animate-pulse">
              <AlertCircle className="w-12 h-12 text-moov-gold" />
            </div>
            <div className="space-y-4">
              <h3 className="text-2xl font-black font-display text-moov-gold">{t.connection_status}</h3>
              <p className={`text-sm font-bold leading-relaxed ${userProfile.isDarkTheme ? 'text-white/70' : 'text-zinc-600'}`}>
                {t.notification_permission}
              </p>
            </div>
            <div className="flex flex-col gap-3">
              <button 
                onClick={requestNotificationPermission}
                className="w-full py-5 bg-moov-gold text-black font-black rounded-3xl shadow-xl shadow-moov-gold/30 active:scale-95 transition-all"
              >
                {t.allow}
              </button>
              <button 
                onClick={() => setIsNotificationModalOpen(false)}
                className={`w-full py-4 font-black text-sm transition-all ${userProfile.isDarkTheme ? 'text-white/40 hover:text-white' : 'text-zinc-400 hover:text-zinc-900'}`}
              >
                {t.deny}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );

  const LoginScreen = () => (
    <div className={`min-h-screen flex flex-col items-center justify-center p-8 space-y-12 relative overflow-hidden gpu-accelerated ${userProfile.isDarkTheme ? 'bg-black text-white' : 'bg-zinc-50 text-zinc-900'}`}>
      <div className="absolute top-[-10%] left-[-10%] w-80 h-80 bg-moov-purple/20 rounded-full blur-[120px]" />
      <div className="absolute bottom-[-10%] right-[-10%] w-80 h-80 bg-moov-gold/20 rounded-full blur-[120px]" />

      {/* Motorcycle Silhouette Background */}
      <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none select-none z-0">
        <svg viewBox="0 0 24 24" className="w-[150%] h-[150%] text-white fill-current transform -rotate-12 translate-x-1/4">
          <path d="M19.5,13.5C18.12,13.5 17,14.62 17,16C17,17.38 18.12,18.5 19.5,18.5C20.88,18.5 22,17.38 22,16C22,14.62 20.88,13.5 19.5,13.5M4.5,13.5C3.12,13.5 2,14.62 2,16C2,17.38 3.12,18.5 4.5,18.5C5.88,18.5 7,17.38 7,16C7,14.62 5.88,13.5 4.5,13.5M19.5,12C21.71,12 23.5,13.79 23.5,16C23.5,18.21 21.71,20 19.5,20C17.29,20 15.5,18.21 15.5,16C15.5,13.79 17.29,12 19.5,12M4.5,12C6.71,12 8.5,13.79 8.5,16C8.5,18.21 6.71,20 4.5,20C2.29,20 0.5,18.21 0.5,16C0.5,13.79 2.29,12 4.5,12M18,10V7H15V4H13V7H10V4H8V7H5V10H18M19,11H4V13H19V11Z" />
        </svg>
      </div>

      <motion.div 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={springTransition}
        className="text-center space-y-4 relative z-10"
      >
        <div className="flex justify-center mb-6">
          <MoovLogo />
        </div>
        <div className="relative">
          <h1 className="text-5xl font-black font-display tracking-tighter text-moov-gold bg-gradient-to-b from-moov-gold to-moov-yellow bg-clip-text text-transparent drop-shadow-[0_0_15px_rgba(255,215,0,0.3)]">{t.welcome_title}</h1>
          <div className="text-moov-yellow font-black text-xl mt-2 drop-shadow-md">{t.welcome_arabic}</div>
          <div className="absolute -inset-1 bg-moov-gold/20 blur-2xl -z-10 rounded-full" />
        </div>
        <p className="text-lg font-bold opacity-60">{t.welcome_subtitle}</p>
      </motion.div>

      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ ...springTransition, delay: 0.1 }}
        className="w-full max-w-sm space-y-4 relative z-10"
      >
        <button 
          onClick={() => handleOAuthLogin('google')}
          className={`w-full flex items-center justify-center gap-4 p-5 rounded-3xl font-black shadow-lg transition-all active:scale-95 ${userProfile.isDarkTheme ? 'bg-white text-black hover:bg-zinc-200' : 'bg-white border-2 border-zinc-100 text-zinc-900 hover:bg-zinc-50'}`}
        >
          <svg className="w-6 h-6" viewBox="0 0 24 24">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-1 .67-2.28 1.07-3.71 1.07-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
            <path fill="#FBBC05" d="M5.84 14.11c-.22-.66-.35-1.36-.35-2.11s.13-1.45.35-2.11V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.83z"/>
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.83c.87-2.6 3.3-4.53 6.16-4.53z"/>
          </svg>
          {t.login_google}
        </button>

        <div className="flex items-center gap-4 py-4">
          <div className="flex-1 h-px bg-white/10" />
          <span className="text-[10px] font-black text-white/30 uppercase tracking-widest">OR</span>
          <div className="flex-1 h-px bg-white/10" />
        </div>

        <button 
          onClick={handleGuestLogin}
          className={`w-full p-5 rounded-3xl font-black transition-all active:scale-95 ${userProfile.isDarkTheme ? 'bg-white/5 text-white hover:bg-white/10' : 'bg-zinc-100 text-zinc-900 hover:bg-zinc-200'}`}
        >
          {t.login_guest}
        </button>

        <button 
          onClick={() => setIsDirectLoginOpen(true)}
          className={`w-full p-5 rounded-3xl font-black transition-all active:scale-95 border-2 border-moov-gold/30 text-moov-gold hover:bg-moov-gold/5`}
        >
          {t.login_direct}
        </button>

        <button 
          onClick={() => setIsLoginModalOpen(true)}
          className={`w-full p-5 rounded-3xl font-black transition-all active:scale-95 bg-moov-purple-neon/10 text-moov-purple-neon border border-moov-purple-neon/20 hover:bg-moov-purple-neon/20`}
        >
          {t.login_driver}
        </button>
      </motion.div>

      <div className="mt-auto pb-8 text-center space-y-1">
        <p className="text-[10px] font-black text-moov-gold uppercase tracking-widest opacity-40">© 2026 MOOV DELIVERY GAZA</p>
        <p className="text-[9px] font-black text-white/30 uppercase tracking-wide">{t.developed_by}</p>
      </div>
    </div>
  );

  return (
    <div 
      className="min-h-screen flex flex-col max-w-md mx-auto bg-transparent shadow-2xl relative overflow-hidden text-white gpu-accelerated"
      dir={userProfile.language === 'ar' ? 'rtl' : 'ltr'}
    >
      {NotificationModal()}
      {PremiumModal()}
      
      {!userProfile.isAuthenticated ? (
        LoginScreen()
      ) : (
        <>
          {Header()}

          {/* Driver Dashboard Banner */}
          {authenticatedDriver && (
            <div className="bg-moov-purple-neon/20 border-b border-moov-purple-neon/30 p-3 flex items-center justify-between backdrop-blur-md">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-moov-gold/20 flex items-center justify-center border border-moov-gold/30">
                  <User className="w-4 h-4 text-moov-gold" />
                </div>
                <div>
                  <div className="text-[10px] text-white/40 font-bold uppercase tracking-wider">{t.driver_account}</div>
                  <div className="text-xs font-black text-white">{authenticatedDriver.name}</div>
                </div>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => setView('orders')}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-black transition-all ${view === 'orders' ? 'bg-moov-purple-neon text-white' : 'bg-white/5 text-moov-purple-neon border border-moov-purple-neon/20'}`}
                >
                  {t.orders}
                </button>
                <button 
                  onClick={handleLogout}
                  className="px-3 py-1.5 bg-red-500/10 border border-red-500/20 text-red-500 rounded-xl text-[10px] font-black hover:bg-red-500 hover:text-white transition-all"
                >
                  {t.logout}
                </button>
              </div>
            </div>
          )}

      <main className="flex-1 overflow-y-auto p-4 max-w-md mx-auto w-full">
        <AnimatePresence mode="wait">
          {view === 'customer_view' && selectedOrderIdForTracking && (
            <motion.div 
              key="customer_view"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              {orders.find(o => o.id === selectedOrderIdForTracking) ? (
                CustomerTrackingView({ order: orders.find(o => o.id === selectedOrderIdForTracking)! })
              ) : (
                <div className="text-center py-20 text-white/20 italic">{t.no_orders}</div>
              )}
            </motion.div>
          )}

          {view === 'map_tracking' && trackingOrder && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="h-[60vh] relative rounded-[2.5rem] overflow-hidden border-4 border-moov-gold shadow-2xl"
            >
              <MapContainer center={[trackingOrder.driverLocation?.lat || 31.4175, trackingOrder.driverLocation?.lng || 34.3509]} zoom={15} style={{ height: '100%', width: '100%' }}>
                <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                {trackingOrder.driverLocation && (
                  <Marker position={[trackingOrder.driverLocation.lat, trackingOrder.driverLocation.lng]} icon={DriverIcon}>
                    <Popup>{t.driver_location}</Popup>
                  </Marker>
                )}
                {trackingOrder.customerLocation && (
                  <Marker position={[trackingOrder.customerLocation.lat, trackingOrder.customerLocation.lng]} icon={CustomerIcon}>
                    <Popup>{t.your_location}</Popup>
                  </Marker>
                )}
                <MapUpdater center={[trackingOrder.driverLocation?.lat || 31.4175, trackingOrder.driverLocation?.lng || 34.3509]} />
              </MapContainer>
              <div className="absolute top-4 left-4 right-4 z-[1000]">
                <div className="bg-black/60 backdrop-blur-md p-4 rounded-2xl border border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-moov-gold/20 rounded-full flex items-center justify-center">
                      <Clock className="w-5 h-5 text-moov-gold" />
                    </div>
                    <div>
                      <p className="text-[10px] text-white/40 font-black uppercase">{t.eta}</p>
                      <p className="text-sm font-black text-white">{trackingOrder.eta || 'Calculating...'}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setView('regions')}
                    className="p-2 bg-white/10 rounded-xl text-white hover:bg-white/20 transition-all"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {view === 'chat_list' && authenticatedDriver && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-black font-display text-moov-gold">{t.chat_list_title}</h2>
                <button 
                  onClick={() => setView('regions')}
                  className="p-2 bg-white/5 rounded-xl text-white/40 hover:text-white transition-colors"
                >
                  <ArrowRight className={`w-5 h-5 ${userProfile.language === 'en' ? 'rotate-180' : ''}`} />
                </button>
              </div>

              <div className="space-y-3">
                {chatRooms.filter(room => room.driverId === authenticatedDriver.id).length === 0 ? (
                  <div className="text-center py-20 text-white/20 italic">{t.no_active_chats}</div>
                ) : (
                  chatRooms.filter(room => room.driverId === authenticatedDriver.id).map(room => (
                    <div 
                      key={room.id}
                      onClick={() => {
                        setSelectedDriverId(room.driverId);
                        // We need a way to track which customer we are chatting with
                        // For now, let's assume the chat view handles it or we use a new state
                        setView('chat');
                      }}
                      className="bg-black/40 border-2 border-white/10 p-5 rounded-3xl flex items-center justify-between hover:border-moov-gold transition-all cursor-pointer backdrop-blur-md"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-moov-purple/20 rounded-2xl flex items-center justify-center border border-moov-gold/30">
                          <User className="w-6 h-6 text-moov-gold" />
                        </div>
                        <div>
                          <h4 className="font-black text-white">{room.customerName}</h4>
                          <p className="text-xs text-white/40 truncate max-w-[150px]">{room.lastMessage || t.chat_try_hello}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        {room.unreadCount > 0 && (
                          <span className="bg-moov-purple-neon text-white text-[10px] font-black px-2 py-1 rounded-full">
                            {room.unreadCount}
                          </span>
                        )}
                        <p className="text-[10px] text-white/20 mt-1">
                          {room.lastMessageTime ? new Date(room.lastMessageTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          )}

          {view === 'admin_logs' && isAdminAuthenticated && (
            <motion.div 
              key="admin_logs"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-black font-display text-moov-gold">{t.admin_logs}</h2>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => {
                      fetch('/api/notifications/broadcast', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ message: t.new_discount_alert })
                      });
                      sendRealNotification('MOOV Delivery', t.new_discount_alert);
                      setSuccessMessage(t.new_discount_alert);
                      setIsSuccessModalOpen(true);
                    }}
                    className="flex items-center gap-2 px-4 py-2 bg-moov-gold text-black rounded-xl text-[10px] font-black shadow-lg shadow-moov-gold/30 active:scale-95 transition-all"
                  >
                    <Gift className="w-4 h-4" />
                    Broadcast Discount
                  </button>
                  <button 
                    onClick={() => setView('regions')}
                    className="p-2 bg-white/5 rounded-xl text-white/40 hover:text-white transition-colors"
                  >
                    <ArrowRight className={`w-5 h-5 ${userProfile.language === 'en' ? 'rotate-180' : ''}`} />
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                {logs.length === 0 ? (
                  <div className="text-center py-20 text-white/20 italic">{t.no_logs}</div>
                ) : (
                  logs.map(log => (
                    <div key={log.id} className="bg-black/40 border border-white/10 p-4 rounded-2xl space-y-2 backdrop-blur-md">
                      <div className="flex justify-between items-start">
                        <span className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest ${
                          log.type === 'order_received' ? 'bg-blue-500/20 text-blue-400' :
                          log.type === 'payment_verified' ? 'bg-emerald-500/20 text-emerald-400' :
                          log.type === 'order_completed' ? 'bg-purple-500/20 text-purple-400' :
                          'bg-moov-gold/20 text-moov-gold'
                        }`}>
                          {log.type.replace('_', ' ')}
                        </span>
                        <span className="text-[10px] text-white/20 font-mono">
                          {new Date(log.timestamp).toLocaleTimeString(userProfile.language === 'ar' ? 'ar-EG' : 'en-US')}
                        </span>
                      </div>
                      <p className="text-sm font-bold text-white/80 leading-relaxed">{log.message}</p>
                      {log.amount && (
                        <div className="text-xs font-black text-moov-gold">
                          {t.amount}: {log.amount} pts
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          )}
          {view === 'job_applications' && isAdminAuthenticated && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-moov-gold/20 rounded-2xl flex items-center justify-center border border-moov-gold/30">
                  <User className="w-6 h-6 text-moov-gold" />
                </div>
                <h2 className="text-2xl font-black font-display">{t.job_applications}</h2>
              </div>

              <div className="space-y-4">
                {jobApplications.length === 0 ? (
                  <div className="text-center py-20 bg-white/5 rounded-[2.5rem] border border-dashed border-white/10">
                    <p className="text-white/40 font-bold">{t.no_logs}</p>
                  </div>
                ) : (
                  jobApplications.map(app => (
                    <div key={app.id} className="bg-white/5 border border-white/10 rounded-[2rem] p-6 space-y-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-black text-white">{app.name}</h3>
                          <p className="text-xs text-white/40">{new Date(app.timestamp).toLocaleString()}</p>
                        </div>
                        <div className="px-3 py-1 bg-moov-gold/20 text-moov-gold rounded-full text-[10px] font-black uppercase">
                          {app.city}
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="space-y-1">
                          <p className="text-[10px] text-white/40 font-bold uppercase">{t.contact_email_label}</p>
                          <p className="font-bold text-white break-all">{app.email}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-[10px] text-white/40 font-bold uppercase">{t.age} / {t.dob}</p>
                          <p className="font-bold text-white">{app.age} / {app.dob}</p>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <p className="text-[10px] text-white/40 font-bold uppercase">{t.delivery_experience}</p>
                        <p className="text-sm text-white/80 leading-relaxed">{app.experience}</p>
                      </div>

                      {app.idPhoto && (
                        <div className="space-y-2">
                          <p className="text-[10px] text-white/40 font-bold uppercase">{t.id_photo}</p>
                          <div className="relative aspect-video rounded-xl overflow-hidden border border-white/10">
                            <img 
                              src={app.idPhoto} 
                              alt="ID Photo" 
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          )}

          {view === 'regions' && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
            >
              {/* Elegant Back to Login Button */}
              {!isAdminAuthenticated && !authenticatedDriver && (
                <motion.button 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  onClick={handleLogout}
                  className="w-full group relative overflow-hidden p-0.5 rounded-[2rem] bg-gradient-to-r from-moov-gold via-moov-purple-neon to-moov-gold bg-[length:200%_auto] animate-gradient-x shadow-xl shadow-moov-gold/20 active:scale-95 transition-all mb-4"
                >
                  <div className="bg-black/80 backdrop-blur-xl rounded-[1.9rem] py-4 px-6 flex items-center justify-between group-hover:bg-black/60 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-moov-gold/20 rounded-xl flex items-center justify-center border border-moov-gold/30">
                        <LogOut className="w-5 h-5 text-moov-gold" />
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] text-moov-gold font-black uppercase tracking-widest">{t.back_box}</p>
                        <p className="text-xs font-bold text-white/60">{t.logout}</p>
                      </div>
                    </div>
                    <div className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center group-hover:bg-moov-gold group-hover:text-black transition-all">
                      <ArrowRight className={`w-5 h-5 ${userProfile.language === 'en' ? 'rotate-180' : ''}`} />
                    </div>
                  </div>
                </motion.button>
              )}

              {/* Smart Search Bar */}
              <div className="relative mb-6">
                <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                  <Search className="w-5 h-5 text-white/30" />
                </div>
                <input 
                  type="text"
                  placeholder={t.search_placeholder}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-white/5 border-2 border-white/10 rounded-3xl py-4 pl-12 pr-6 text-sm font-bold focus:border-moov-gold/50 focus:bg-white/10 transition-all outline-none"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="absolute inset-y-0 right-4 flex items-center text-white/30 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {isAdminAuthenticated && (
                <div className="flex justify-between items-center bg-emerald-500/10 p-4 rounded-2xl border border-emerald-500/30 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-emerald-500/20 rounded-full flex items-center justify-center border border-emerald-500/30">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] text-emerald-500 font-bold uppercase">{t.admin_account}</p>
                      <p className="text-sm font-black text-white">{ADMIN_CREDENTIALS.username}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => setView('admin_logs')}
                      className={`px-4 py-2 rounded-xl text-[10px] font-black transition-all ${view === 'admin_logs' ? 'bg-moov-gold text-black' : 'bg-white/10 text-moov-gold border border-moov-gold/20 hover:bg-white/20'}`}
                    >
                      {t.admin_logs}
                    </button>
                    <button 
                      onClick={() => setView('job_applications')}
                      className={`px-4 py-2 rounded-xl text-[10px] font-black transition-all ${view === 'job_applications' ? 'bg-moov-gold text-black' : 'bg-white/10 text-moov-gold border border-moov-gold/20 hover:bg-white/20'}`}
                    >
                      {t.job_applications}
                    </button>
                    <button 
                      onClick={handleLogout}
                      className="px-4 py-2 bg-moov-red/10 border border-moov-red/20 text-moov-red rounded-xl text-[10px] font-black hover:bg-moov-red hover:text-white transition-all"
                    >
                      {t.logout}
                    </button>
                  </div>
                </div>
              )}

              {/* Back to Login Button for Users REMOVED (Moved above search) */}
              {userProfile.isGuest && (
                <div className="bg-moov-red/20 p-4 rounded-2xl border border-moov-red/30 mb-6 backdrop-blur-md">
                  <p className="text-moov-red font-bold text-xs text-center drop-shadow-sm flex items-center justify-center gap-2">
                    <AlertCircle className="w-4 h-4" />
                    {t.guest_restriction}
                  </p>
                </div>
              )}
              <div className="bg-moov-gold/10 p-5 rounded-[2rem] border-2 border-moov-gold/30 mb-6 backdrop-blur-md shadow-[0_0_20px_rgba(255,215,0,0.1)]">
                <p className="text-moov-gold font-black text-sm text-center drop-shadow-md flex items-center justify-center gap-2">
                  <Gift className="w-5 h-5 animate-bounce" />
                  {t.loyalty_msg.split('!')[0]}!
                </p>
              </div>

              {/* My Active Orders (Customer Tracking) */}
              {!isAdminAuthenticated && !authenticatedDriver && orders.filter(o => o.status !== 'completed' && o.status !== 'cancelled').length > 0 && (
                <div className="space-y-4 mb-8">
                  <h3 className="text-moov-gold font-black text-sm flex items-center gap-2 px-2">
                    <ShoppingBag className="w-4 h-4" />
                    {t.my_orders}
                  </h3>
                  <div className="space-y-3">
                    {orders.filter(o => o.status !== 'completed' && o.status !== 'cancelled').map(order => (
                      <div key={order.id} className="bg-black/40 border-2 border-white/10 p-5 rounded-3xl backdrop-blur-md">
                        <div className="flex justify-between items-center mb-4">
                          <div>
                            <p className="text-[10px] text-white/40 font-black uppercase tracking-wider">{t.order_id}: #{order.id.slice(-4)}</p>
                            <h4 className="font-black text-white">{order.regionName}</h4>
                          </div>
                          <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase ${
                            order.status === 'accepted' ? 'bg-blue-500/20 text-blue-500' :
                            order.status === 'delivering' ? 'bg-amber-500/20 text-amber-500' :
                            'bg-white/10 text-white/40'
                          }`}>
                            {order.status}
                          </div>
                        </div>
                        {(order.status === 'accepted' || order.status === 'delivering') && (
                          <button 
                            onClick={() => {
                              setTrackingOrder(order);
                              setView('map_tracking');
                            }}
                            className="w-full py-3 bg-moov-gold/10 border border-moov-gold/30 text-moov-gold font-black rounded-2xl text-xs flex items-center justify-center gap-2 hover:bg-moov-gold hover:text-black transition-all"
                          >
                            <MapPin className="w-4 h-4" />
                            {t.track_order}
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {regions.length === 0 ? (
                <div className="text-center py-20 text-white/40 italic">{t.no_orders}</div>
              ) : (
                <>
                  {regions
                    .filter(region => {
                      if (!searchQuery) return true;
                      const query = searchQuery.toLowerCase();
                      const matchesRegion = region.name.toLowerCase().includes(query);
                      const matchesRestaurant = region.restaurants?.some(res => res.name.toLowerCase().includes(query));
                      return matchesRegion || matchesRestaurant;
                    })
                    .map((region, idx) => (
                    <motion.div 
                      key={region.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      onClick={() => { setSelectedRegionId(region.id); setView('drivers'); }}
                      className="group relative overflow-hidden cursor-pointer p-0.5 rounded-[2.5rem] bg-gradient-to-br from-moov-gold via-transparent to-moov-purple/40 hover:from-moov-gold hover:via-moov-purple-neon hover:to-moov-gold bg-[length:200%_auto] animate-gradient-x transition-all active:scale-[0.98] shadow-[0_0_20px_rgba(255,215,0,0.3)] hover:shadow-[0_0_35px_rgba(255,215,0,0.6)] transition-shadow duration-500"
                    >
                      <div className="bg-[#1A0B2E]/90 backdrop-blur-xl rounded-[2.4rem] p-6 flex items-center justify-between relative z-10 group-hover:bg-[#1A0B2E]/70 transition-colors">
                        <div className="flex items-center gap-5">
                          <div className="w-14 h-14 bg-gradient-to-br from-moov-purple to-moov-purple-neon rounded-2xl flex items-center justify-center border-2 border-white/20 shadow-lg shadow-moov-purple/30 group-hover:scale-110 transition-transform duration-500">
                            <MapPin className="w-7 h-7 text-white" />
                          </div>
                          <div>
                            <span className="text-xl font-black font-display text-white drop-shadow-md block">{region.name}</span>
                            <span className="text-[10px] font-bold text-moov-gold/60 uppercase tracking-widest">{region.drivers.length} {t.driver_label}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {isAdminAuthenticated && (
                            <div className="flex items-center gap-1">
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setEditingRegion(region);
                                  setIsRegionModalOpen(true);
                                }}
                                className="p-2 hover:bg-white/10 rounded-xl transition-colors text-moov-gold"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setDeleteConfirmation({ type: 'region', id: region.id, name: region.name });
                                }}
                                className="p-2 hover:bg-red-500/20 rounded-xl transition-colors text-moov-red"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          )}
                          <div className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center group-hover:bg-moov-gold group-hover:text-black transition-all">
                            <ArrowRight className={`w-5 h-5 ${userProfile.language === 'en' ? 'rotate-180' : ''}`} />
                          </div>
                        </div>
                      </div>
                      
                      {/* Decorative elements */}
                      <div className="absolute top-0 right-0 w-32 h-32 bg-moov-gold/5 rounded-full blur-3xl -mr-16 -mt-16 group-hover:bg-moov-gold/10 transition-colors" />
                    </motion.div>
                  ))}

                  {/* Support & Job Section */}
                  <div className="pt-8 space-y-4">
                    <a 
                      href="https://wa.me/970567276125" 
                      target="_blank" 
                      rel="noreferrer"
                      className="flex items-center justify-center gap-3 w-full p-5 bg-emerald-600 hover:bg-emerald-700 rounded-3xl font-black text-white shadow-lg transition-all active:scale-95"
                    >
                      <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                      </svg>
                      {t.support}
                    </a>

                    {!isAdminAuthenticated && (
                      <div className="bg-moov-purple-neon/10 border-2 border-moov-purple-neon/30 rounded-[2.5rem] p-8 backdrop-blur-md">
                        <div className="flex items-center gap-3 mb-4 text-moov-gold">
                          <User className="w-6 h-6" />
                          <h3 className="text-xl font-black font-display">{t.apply_job}</h3>
                        </div>
                        <p className="text-sm text-white/70 mb-6 leading-relaxed">
                          {userProfile.language === 'ar' 
                            ? t.job_desc
                            : "Do you have a bicycle or electric bike? Are you reliable and honest? Join us now as a delivery partner."}
                        </p>
                        <button 
                          onClick={() => setIsJobModalOpen(true)}
                          className="w-full py-4 bg-moov-gold text-black font-black rounded-2xl shadow-lg shadow-moov-gold/20 hover:bg-yellow-400 transition-all active:scale-95"
                        >
                          {t.job_application}
                        </button>

                        {/* Social Media Section */}
                        <div className="mt-8 text-center space-y-4">
                          <p className="text-[10px] font-black text-moov-gold uppercase tracking-widest leading-relaxed">
                            {t.follow_us}
                          </p>
                          <div className="flex justify-center gap-4">
                            <a 
                              href="https://wa.me/970567276125" 
                              target="_blank" 
                              rel="noreferrer"
                              className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10 hover:border-moov-gold hover:bg-moov-gold/10 transition-all group"
                              title="WhatsApp"
                            >
                              <svg className="w-5 h-5 fill-white group-hover:fill-moov-gold transition-colors" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                              </svg>
                            </a>
                            <a 
                              href="https://twitter.com/moovdelivary101" 
                              target="_blank" 
                              rel="noreferrer"
                              className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10 hover:border-moov-gold hover:bg-moov-gold/10 transition-all group"
                              title={t.twitter}
                            >
                              <Twitter className="w-5 h-5 text-white group-hover:text-moov-gold transition-colors" />
                            </a>
                            <a 
                              href="https://instagram.com/moov.delivary" 
                              target="_blank" 
                              rel="noreferrer"
                              className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10 hover:border-moov-gold hover:bg-moov-gold/10 transition-all group"
                              title={t.instagram}
                            >
                              <Instagram className="w-5 h-5 text-white group-hover:text-moov-gold transition-colors" />
                            </a>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Developer Credit Box */}
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6 }}
                    className="mt-12 p-6 rounded-[2rem] bg-gradient-to-br from-black/60 to-moov-purple/20 border-2 border-moov-gold/20 backdrop-blur-xl text-center shadow-2xl relative overflow-hidden group"
                  >
                    <div className="absolute inset-0 bg-moov-gold/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    <div className="relative z-10">
                      <div className="w-12 h-12 bg-moov-gold/10 rounded-2xl flex items-center justify-center mx-auto mb-3 border border-moov-gold/20">
                        <Globe className="w-6 h-6 text-moov-gold animate-pulse" />
                      </div>
                      <p className="text-sm font-black text-white leading-relaxed">
                        {t.developed_by}
                      </p>
                      <div className="mt-2 flex items-center justify-center gap-2">
                        <div className="h-px w-8 bg-moov-gold/30" />
                        <span className="text-[10px] font-black text-moov-gold uppercase tracking-[0.2em]">Sky Gaza Tech</span>
                        <div className="h-px w-8 bg-moov-gold/30" />
                      </div>
                    </div>
                  </motion.div>
                </>
              )}
            </motion.div>
          )}

          {view === 'orders' && selectedDriver && (
            <motion.div 
              key="orders"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              {/* Driver Chat List Button */}
              <button 
                onClick={() => setView('chat_list')}
                className="w-full py-4 bg-moov-purple/20 border-2 border-moov-purple/50 rounded-3xl flex items-center justify-center gap-3 text-moov-purple-neon font-black hover:bg-moov-purple/30 transition-all"
              >
                <MessageCircle className="w-5 h-5" />
                {t.chat_list_title}
              </button>

              {/* Available Orders */}
              <div className="space-y-4">
                <h3 className="text-moov-gold font-black text-sm flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4" />
                  {t.available_orders}
                </h3>
                {orders.filter(o => o.regionName.includes(selectedRegion?.name || '') && o.status === 'pending').map(order => (
                  <div key={order.id} className="bg-black/40 border-2 border-moov-gold/30 rounded-3xl p-6 backdrop-blur-md">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h4 className="text-xl font-black font-display text-white/40">{t.new_customer}</h4>
                        <p className="text-xs text-white/20 italic">{order.regionName}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-black text-moov-gold">{order.price} pts</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => handleAcceptOrder(order)}
                      className="w-full btn-primary py-4 flex items-center justify-center gap-2"
                    >
                      <CheckCircle2 className="w-5 h-5" />
                      {t.accept_order}
                    </button>
                  </div>
                ))}
                {orders.filter(o => o.regionName.includes(selectedRegion?.name || '') && o.status === 'pending').length === 0 && (
                  <div className="text-center py-4 text-white/20 text-xs">{t.no_orders}</div>
                )}
              </div>

              {/* Accepted Orders (Active) */}
              {orders.filter(o => o.regionName.includes(selectedRegion?.name || '') && o.status === 'accepted').length > 0 && (
                <div className="space-y-4 mt-8">
                  <h3 className="text-emerald-500 font-black text-sm flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    {t.active_orders}
                  </h3>
                  {orders.filter(o => o.regionName.includes(selectedRegion?.name || '') && o.status === 'accepted').map(order => (
                    <div key={order.id} className="bg-emerald-500/10 border-2 border-emerald-500/50 rounded-3xl p-6 backdrop-blur-md">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h4 className="text-xl font-black font-display text-white">{order.customerName}</h4>
                          <p className="text-xs text-emerald-500 font-bold">{t.details_unlocked}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-black text-moov-gold">{order.price} pts</p>
                        </div>
                      </div>
                      <div className="space-y-4 mb-4">
                        <div className="flex gap-2">
                          <input 
                            type="text" 
                            placeholder={t.eta_placeholder}
                            className="flex-1 bg-black/40 border border-white/10 rounded-xl px-4 text-xs text-white"
                            value={etaInput}
                            onChange={e => setEtaInput(e.target.value)}
                          />
                          <button 
                            onClick={() => handleUpdateOrderStatus(order.id, 'preparing', etaInput)}
                            className="px-4 py-2 bg-moov-gold text-black text-[10px] font-black rounded-xl"
                          >
                            Update ETA
                          </button>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-2">
                          <button 
                            onClick={() => handleUpdateOrderStatus(order.id, 'preparing')}
                            className={`py-2 rounded-xl text-[10px] font-black ${order.status === 'preparing' ? 'bg-moov-gold text-black' : 'bg-white/5 text-white/40'}`}
                          >
                            {t.preparing}
                          </button>
                          <button 
                            onClick={() => handleUpdateOrderStatus(order.id, 'delivering')}
                            className={`py-2 rounded-xl text-[10px] font-black ${order.status === 'delivering' ? 'bg-moov-gold text-black' : 'bg-white/5 text-white/40'}`}
                          >
                            {t.delivering}
                          </button>
                          <button 
                            onClick={() => handleUpdateOrderStatus(order.id, 'arriving')}
                            className={`py-2 rounded-xl text-[10px] font-black ${order.status === 'arriving' ? 'bg-moov-gold text-black' : 'bg-white/5 text-white/40'}`}
                          >
                            {t.arriving}
                          </button>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <button 
                          onClick={() => {
                            setSelectedDriverId(authenticatedDriver?.id || selectedDriverId);
                            setView('chat');
                          }}
                          className="flex-1 bg-moov-purple-neon hover:bg-moov-purple text-white py-4 rounded-2xl font-black flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-moov-purple/40"
                        >
                          <MessageSquare className="w-5 h-5" />
                          {t.chat_title}
                        </button>
                        <button 
                          onClick={() => handleCompleteOrder(order.id)}
                          className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white py-4 rounded-2xl font-black flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-emerald-500/40"
                        >
                          <CheckCircle2 className="w-5 h-5" />
                          {t.complete_order_btn}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
          {view === 'drivers' && selectedRegion && (
            <motion.div 
              key="drivers"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              {selectedRegion.drivers.length === 0 ? (
                <div className="text-center py-20 text-white/40">{t.no_drivers}</div>
              ) : (
                selectedRegion.drivers.map(driver => (
                  <div 
                    key={driver.id}
                    onClick={() => { setSelectedDriverId(driver.id); setView('chat'); }}
                    className="group relative overflow-hidden cursor-pointer p-4 rounded-3xl bg-black/40 border-2 border-moov-gold/30 shadow-[0_0_15px_rgba(255,215,0,0.1)] hover:border-moov-gold hover:shadow-[0_0_25px_rgba(255,215,0,0.3)] transition-all active:scale-[0.98] backdrop-blur-md"
                  >
                    <div className="flex items-center justify-between relative z-10">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 rounded-2xl bg-moov-purple-neon/20 flex items-center justify-center border-2 border-moov-gold shadow-[0_0_15px_rgba(255,215,0,0.5)]">
                          <User className="w-7 h-7 text-moov-gold" />
                        </div>
                        <div>
                          <div className="text-lg font-black font-display text-white">{driver.name}</div>
                          <div className="flex items-center gap-1 text-moov-gold">
                            <Star className="w-4 h-4 fill-current" />
                            <span className="text-sm font-bold">{driver.rating.toFixed(1)}</span>
                          </div>
                        </div>
                      </div>
                      {isAdminAuthenticated && (
                        <div className="flex items-center gap-1">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              checkAdminPassword(() => {
                                setEditingDriver(driver);
                                setIsDriverModalOpen(true);
                              });
                            }}
                            className="p-2 hover:bg-white/10 rounded-xl transition-colors text-moov-gold"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              checkAdminPassword(() => {
                                setDeleteConfirmation({ type: 'driver', id: driver.id, name: driver.name, parentId: selectedRegion.id });
                              });
                            }}
                            className="p-2 hover:bg-red-500/20 rounded-xl transition-colors text-moov-red"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </motion.div>
          )}

          {view === 'chat' && selectedDriver && (
            <motion.div 
              key="chat"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex flex-col h-full"
            >
              <div className="flex-1 space-y-4 pb-24">
                {currentMessages.length === 0 ? (
                  <div className="text-center py-20 text-white/20 flex flex-col items-center gap-4">
                    <div className="w-20 h-20 bg-moov-gold rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(255,215,0,0.3)]">
                      <MessageSquare className="w-10 h-10 text-moov-purple" />
                    </div>
                    <p className="font-bold text-white/60">{t.start_chat_msg.replace('{name}', selectedDriver.name)}</p>
                    <p className="text-xs text-moov-gold font-bold animate-pulse">{t.try_hello_msg}</p>
                  </div>
                ) : (
                  currentMessages.map(msg => (
                    <div 
                      key={msg.id}
                      className={`flex ${msg.isUserMessage ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`
                        max-w-[80%] p-4 rounded-3xl text-sm font-medium shadow-lg
                        ${msg.isUserMessage 
                          ? 'bg-moov-purple-neon text-white rounded-tr-none border border-white/20' 
                          : 'bg-black/60 border-2 border-moov-gold/30 text-white rounded-tl-none backdrop-blur-md'}
                      `}>
                        {msg.text}
                      </div>
                    </div>
                  ))
                )}
                <div ref={chatEndRef} />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {userProfile.isAuthenticated && view === 'chat' && (
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-black/40 backdrop-blur-xl border-t border-moov-gold/30">
          <ChatInput onSend={sendMessage} t={t} />
        </div>
      )}
    </>
  )}

  {/* Modals */}
      <Modal 
        isOpen={isAdminPasswordModalOpen} 
        onClose={() => setIsAdminPasswordModalOpen(false)}
        title={t.admin_password_required}
      >
        <form onSubmit={handleAdminPasswordSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-black text-moov-gold uppercase tracking-widest">{t.enter_admin_password}</label>
            <input 
              type="password" 
              value={adminPasswordInput}
              onChange={(e) => setAdminPasswordInput(e.target.value)}
              className="w-full p-5 bg-black/20 border-2 border-white/10 rounded-2xl focus:border-moov-gold transition-all outline-none font-bold"
              required
              autoFocus
            />
          </div>
          <button 
            type="submit"
            className="w-full py-5 bg-moov-gold text-black font-black rounded-3xl shadow-xl shadow-moov-gold/30 active:scale-95 transition-all"
          >
            {t.ok}
          </button>
        </form>
      </Modal>
      <Modal 
        isOpen={isDirectLoginOpen} 
        onClose={() => setIsDirectLoginOpen(false)}
        title={t.login_direct}
      >
        <form onSubmit={handleDirectLogin} className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-black text-moov-gold uppercase tracking-widest">{t.name_label}</label>
              <input 
                type="text" 
                value={directLoginName}
                onChange={(e) => setDirectLoginName(e.target.value)}
                placeholder={t.enter_name}
                className="w-full p-5 bg-black/20 border-2 border-white/10 rounded-2xl focus:border-moov-gold transition-all outline-none font-bold"
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-black text-moov-gold uppercase tracking-widest">{t.email_label}</label>
              <input 
                type="email" 
                value={directLoginEmail}
                onChange={(e) => setDirectLoginEmail(e.target.value)}
                placeholder={t.email_placeholder}
                className="w-full p-5 bg-black/20 border-2 border-white/10 rounded-2xl focus:border-moov-gold transition-all outline-none font-bold"
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-black text-moov-gold uppercase tracking-widest">{t.referral_code}</label>
              <input 
                type="text" 
                value={referralInput}
                onChange={(e) => setReferralInput(e.target.value)}
                placeholder="ABC123"
                className="w-full p-5 bg-black/20 border-2 border-white/10 rounded-2xl focus:border-moov-gold transition-all outline-none font-bold"
              />
            </div>
          </div>
          <button 
            type="submit"
            className="w-full py-5 bg-moov-gold text-black font-black rounded-3xl shadow-xl shadow-moov-gold/30 active:scale-95 transition-all"
          >
            {t.login}
          </button>
        </form>
      </Modal>

      <Modal 
        isOpen={isRegionModalOpen} 
        onClose={() => setIsRegionModalOpen(false)}
        title={editingRegion ? t.edit_region : t.add_region}
      >
        <RegionForm 
          initialValue={editingRegion?.name || ''} 
          onSubmit={(name) => {
            if (editingRegion) handleUpdateRegion(editingRegion.id, name);
            else handleAddRegion(name);
            setIsRegionModalOpen(false);
          }}
          onCancel={() => setIsRegionModalOpen(false)}
          t={t}
        />
      </Modal>

      <Modal 
        isOpen={isDriverModalOpen} 
        onClose={() => setIsDriverModalOpen(false)}
        title={editingDriver ? t.edit_driver : t.add_driver}
      >
        <DriverForm 
          initialName={editingDriver?.name || ''} 
          initialRating={editingDriver?.rating || 5.0}
          initialPhone={editingDriver?.phone || ''}
          initialUsername={editingDriver?.username || ''}
          initialPassword={editingDriver?.password || ''}
          onSubmit={(name, rating, phone, username, password) => {
            if (selectedRegionId) {
              if (editingDriver) handleUpdateDriver(selectedRegionId, editingDriver.id, name, rating, phone, username, password);
              else handleAddDriver(selectedRegionId, name, rating, phone, username, password);
            }
            setIsDriverModalOpen(false);
          }}
          onCancel={() => setIsDriverModalOpen(false)}
          t={t}
        />
      </Modal>

      <Modal 
        isOpen={isErrorModalOpen} 
        onClose={() => setIsErrorModalOpen(false)}
        title={t.error}
      >
        <div className="space-y-6 text-center">
          <div className="w-20 h-20 bg-red-500/20 rounded-full mx-auto flex items-center justify-center border-2 border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.4)]">
            <AlertCircle className="w-10 h-10 text-red-500" />
          </div>
          <p className="text-lg font-bold leading-relaxed">{errorMessage}</p>
          <button 
            onClick={() => setIsErrorModalOpen(false)}
            className="w-full py-4 bg-red-500 text-white font-black rounded-2xl shadow-lg shadow-red-500/20 active:scale-95 transition-all"
          >
            {t.close}
          </button>
        </div>
      </Modal>

      <Modal 
        isOpen={isSuccessModalOpen} 
        onClose={() => setIsSuccessModalOpen(false)}
        title={t.success}
      >
        <div className="space-y-6 text-center">
          <div className="w-20 h-20 bg-emerald-500/20 rounded-full mx-auto flex items-center justify-center border-2 border-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.4)]">
            <CheckCircle2 className="w-10 h-10 text-emerald-500" />
          </div>
          <p className="text-lg font-bold leading-relaxed">{successMessage}</p>
          <button 
            onClick={() => setIsSuccessModalOpen(false)}
            className="w-full btn-primary py-4"
          >
            {t.ok}
          </button>
        </div>
      </Modal>

      <Modal 
        isOpen={isOrderModalOpen} 
        onClose={() => setIsOrderModalOpen(false)}
        title={t.new_order_title}
      >
        <OrderForm 
          regions={regions}
          onSubmit={(data) => {
            handleAddOrder(data);
            setIsOrderModalOpen(false);
          }}
          onCancel={() => setIsOrderModalOpen(false)}
          t={t}
        />
      </Modal>

      <Modal 
        isOpen={isJobModalOpen} 
        onClose={() => setIsJobModalOpen(false)}
        title={t.job_application_title}
      >
        <JobForm t={t} onSubmit={async (data) => {
          const newApp: JobApplication = {
            id: Date.now().toString(),
            name: data.name,
            age: data.age,
            dob: data.dob,
            email: data.email,
            city: data.city,
            experience: data.experience,
            timestamp: Date.now()
          };

          if (data.idPhoto) {
            const reader = new FileReader();
            reader.onloadend = () => {
              newApp.idPhoto = reader.result as string;
              setJobApplications(prev => [newApp, ...prev]);
              addLog('order_received', `New Job Application from ${data.name} (${data.email})`, undefined, { appId: newApp.id });
            };
            reader.readAsDataURL(data.idPhoto);
          } else {
            setJobApplications(prev => [newApp, ...prev]);
            addLog('order_received', `New Job Application from ${data.name} (${data.email})`, undefined, { appId: newApp.id });
          }
        }} onCancel={() => setIsJobModalOpen(false)} />
      </Modal>

      <Modal 
        isOpen={!!deleteConfirmation} 
        onClose={() => setDeleteConfirmation(null)}
        title={t.confirm_delete}
      >
        <div className="space-y-6">
          <p className="text-center text-white/80">
            {t.delete_msg.replace('{name}', deleteConfirmation?.name || '')}
          </p>
          <div className="flex gap-3">
            <button onClick={() => setDeleteConfirmation(null)} className="flex-1 py-3 rounded-2xl font-bold text-white/40 hover:bg-white/5 transition-colors">{t.cancel}</button>
            <button onClick={handleConfirmDelete} className="flex-1 py-3 bg-red-500 hover:bg-red-600 text-white rounded-2xl font-bold shadow-lg shadow-red-500/20 transition-all active:scale-95">{t.delete}</button>
          </div>
        </div>
      </Modal>

      {/* Login Modal */}
      <AnimatePresence>
        {isLoginModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsLoginModalOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-sm bg-[#1A0B2E] border-4 border-moov-gold rounded-[2.5rem] p-8 shadow-2xl overflow-hidden"
            >
              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-moov-gold/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-moov-gold/20">
                  <User className="w-8 h-8 text-moov-gold" />
                </div>
                <h2 className="text-2xl font-black font-display text-white">{t.login}</h2>
                <p className="text-white/40 text-xs mt-2 italic">{t.login_msg}</p>
              </div>

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-[10px] uppercase font-black text-moov-gold mb-1 px-2 text-right">{t.username_label}</label>
                  <input 
                    type="text"
                    value={loginUsername}
                    onChange={(e) => setLoginUsername(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-4 text-white focus:border-moov-gold outline-none transition-all text-right"
                    placeholder={t.enter_username}
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase font-black text-moov-gold mb-1 px-2 text-right">{t.password_label}</label>
                  <input 
                    type="password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-4 text-white focus:border-moov-gold outline-none transition-all text-right"
                    placeholder="••••••••"
                    required
                  />
                </div>

                <div className="flex items-center justify-end gap-2 px-2">
                  <span className="text-[10px] font-bold text-white/60">{t.remember_me}</span>
                  <input 
                    type="checkbox" 
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 accent-moov-gold rounded"
                  />
                </div>

                {showLoginError && (
                  <motion.p 
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-moov-red text-[10px] font-bold text-center bg-moov-red/10 py-2 rounded-lg px-2"
                  >
                    {loginErrorMessage || t.login_error}
                  </motion.p>
                )}

                <div className="flex gap-3 mt-6">
                  <button 
                    type="button"
                    onClick={() => setIsLoginModalOpen(false)}
                    className="flex-1 py-4 bg-white/5 hover:bg-white/10 text-white font-black rounded-2xl transition-all"
                  >
                    {t.cancel}
                  </button>
                  <button 
                    type="submit"
                    className="flex-[2] btn-primary py-4 flex items-center justify-center gap-2"
                  >
                    {t.login.split(' ')[0]}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {SettingsModal()}
    </div>
  );
}

// --- Sub-components ---

function ChatInput({ onSend, t }: { onSend: (text: string) => void, t: any }) {
  const [text, setText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim()) {
      onSend(text);
      setText('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-2">
      <input 
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder={t.chat_placeholder}
        className="flex-1 input-field"
      />
      <button 
        type="submit"
        className="p-4 bg-moov-gold hover:bg-yellow-400 rounded-2xl transition-all shadow-lg shadow-moov-gold/30 active:scale-90"
      >
        <Send className="w-5 h-5 text-black" />
      </button>
    </form>
  );
}

function Modal({ isOpen, onClose, title, children }: { isOpen: boolean, onClose: () => void, title: string, children: React.ReactNode }) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#1A0B2E] w-full max-w-xs rounded-[2.5rem] p-8 shadow-2xl border-4 border-moov-gold"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-black font-display text-moov-gold drop-shadow-md">{title}</h3>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full"><X className="w-6 h-6 text-white/40" /></button>
        </div>
        {children}
      </motion.div>
    </div>
  );
}

function RegionForm({ initialValue, onSubmit, onCancel, t }: { initialValue: string, onSubmit: (name: string) => void, onCancel: () => void, t: any }) {
  const [name, setName] = useState(initialValue);

  return (
    <div className="space-y-4">
      <input 
        autoFocus
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder={t.region_name}
        className="w-full input-field"
      />
      <div className="flex gap-3 pt-2">
        <button onClick={onCancel} className="flex-1 py-3 rounded-2xl font-bold text-moov-red hover:bg-red-50 transition-colors">{t.cancel}</button>
        <button onClick={() => onSubmit(name)} className="flex-1 btn-primary">{t.save}</button>
      </div>
    </div>
  );
}

function DriverForm({ initialName, initialRating, initialPhone, initialUsername, initialPassword, onSubmit, onCancel, t }: { initialName: string, initialRating: number, initialPhone: string, initialUsername?: string, initialPassword?: string, onSubmit: (name: string, rating: number, phone: string, username?: string, password?: string) => void, onCancel: () => void, t: any }) {
  const [name, setName] = useState(initialName);
  const [rating, setRating] = useState(initialRating);
  const [phone, setPhone] = useState(initialPhone);
  const [username, setUsername] = useState(initialUsername || '');
  const [password, setPassword] = useState(initialPassword || '');

  return (
    <div className="space-y-4">
      <div className="space-y-1">
        <label className="text-xs font-bold text-gray-400 px-1">{t.driver_name}</label>
        <input 
          autoFocus
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder={t.driver_name}
          className="w-full input-field"
        />
      </div>
      <div className="flex gap-2">
        <div className="space-y-1 flex-1">
          <label className="text-xs font-bold text-gray-400 px-1">{t.rating} (0-5)</label>
          <input 
            type="number"
            step="0.1"
            min="0"
            max="5"
            value={rating}
            onChange={(e) => setRating(parseFloat(e.target.value))}
            className="w-full input-field"
          />
        </div>
        <div className="space-y-1 flex-[2]">
          <label className="text-xs font-bold text-gray-400 px-1">{t.phone}</label>
          <input 
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="059xxxxxxx"
            className="w-full input-field"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <div className="space-y-1">
          <label className="text-xs font-bold text-gray-400 px-1">{t.username_label}</label>
          <input 
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="user123"
            className="w-full input-field"
          />
        </div>
        <div className="space-y-1">
          <label className="text-xs font-bold text-gray-400 px-1">{t.password_label}</label>
          <input 
            type="text"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="pass123"
            className="w-full input-field"
          />
        </div>
      </div>

      <div className="flex gap-3 pt-2">
        <button onClick={onCancel} className="flex-1 py-3 rounded-2xl font-bold text-moov-red hover:bg-red-50 transition-colors">{t.cancel}</button>
        <button onClick={() => onSubmit(name, rating, phone, username, password)} className="flex-1 btn-primary">{t.save}</button>
      </div>
    </div>
  );
}

function OrderForm({ regions, onSubmit, onCancel, t }: { regions: Region[], onSubmit: (data: any) => void, onCancel: () => void, t: any }) {
  const [formData, setFormData] = useState({
    customerName: '',
    regionName: '',
    details: '',
    price: ''
  });

  return (
    <div className="space-y-4">
      <div className="space-y-1">
        <label className="text-[10px] font-bold text-white/40 px-1">{t.customer_name}</label>
        <input 
          type="text" 
          placeholder={t.enter_name} 
          className="w-full input-field"
          value={formData.customerName}
          onChange={e => setFormData({...formData, customerName: e.target.value})}
        />
      </div>
      
      <div className="space-y-1">
        <label className="text-[10px] font-bold text-white/40 px-1">{t.region_placeholder}</label>
        <input 
          type="text" 
          placeholder={t.region_manual} 
          className="w-full input-field"
          value={formData.regionName}
          onChange={e => setFormData({...formData, regionName: e.target.value})}
        />
      </div>

      <div className="space-y-1">
        <label className="text-[10px] font-bold text-white/40 px-1">{t.order_details}</label>
        <textarea 
          placeholder={t.what_to_deliver} 
          className="w-full input-field min-h-[100px] py-3"
          value={formData.details}
          onChange={e => setFormData({...formData, details: e.target.value})}
        />
      </div>

      <div className="space-y-1">
        <label className="text-[10px] font-bold text-white/40 px-1">{t.suggested_price} (pts)</label>
        <input 
          type="number" 
          placeholder={t.price_eg} 
          className="w-full input-field font-black text-moov-gold"
          value={formData.price}
          onChange={e => setFormData({...formData, price: e.target.value})}
        />
      </div>

      <div className="flex gap-3 pt-4">
        <button onClick={onCancel} className="flex-1 py-3 text-white/40 font-bold">{t.cancel}</button>
        <button 
          onClick={() => onSubmit({...formData, price: Number(formData.price)})}
          className="flex-[2] btn-primary"
          disabled={!formData.customerName || !formData.details || !formData.price}
        >
          {t.send_order}
        </button>
      </div>
    </div>
  );
}

function JobForm({ onSubmit, onCancel, t }: { onSubmit: (data: any) => void, onCancel: () => void, t: any }) {
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    dob: '',
    email: '',
    city: '',
    experience: '',
    idPhoto: null as File | null
  });

  if (submitted) {
    return (
      <div className="flex flex-col items-center justify-center py-10 text-center space-y-6">
        <div className="w-20 h-20 bg-emerald-500/20 rounded-full flex items-center justify-center border border-emerald-500/30">
          <CheckCircle2 className="w-10 h-10 text-emerald-500" />
        </div>
        <div className="space-y-2">
          <h3 className="text-xl font-black text-white">{t.success}</h3>
          <p className="text-sm text-white/60 leading-relaxed px-4">
            {t.job_success}
          </p>
        </div>
        <button 
          onClick={onCancel}
          className="w-full py-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold hover:bg-white/10 transition-all"
        >
          {t.ok}
        </button>
      </div>
    );
  }

  if (step === 1) {
    return (
      <div className="space-y-6">
        <div className="bg-white/5 p-4 rounded-2xl border border-white/10 space-y-4">
          <h4 className="font-black text-moov-gold">{t.job_terms}:</h4>
          <ul className="text-sm text-white/70 space-y-3">
            <li className="flex gap-2">✅ {t.credibility}</li>
            <li className="flex gap-2">✅ {t.own_bike}</li>
            <li className="flex gap-2">✅ {t.commitment}</li>
            <li className="flex gap-2">✅ {t.job_terms_email}</li>
          </ul>
        </div>
        <button 
          onClick={() => setStep(2)}
          className="w-full btn-primary py-4"
        >
          {t.agree_terms}
        </button>
        <button onClick={onCancel} className="w-full text-white/40 text-sm font-bold">{t.cancel}</button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <input 
        type="text" 
        placeholder={t.full_name} 
        className="w-full input-field"
        value={formData.name}
        onChange={e => setFormData({...formData, name: e.target.value})}
      />
      <div className="flex gap-2">
        <input 
          type="number" 
          placeholder={t.age} 
          className="w-full input-field"
          value={formData.age}
          onChange={e => setFormData({...formData, age: e.target.value})}
        />
        <input 
          type="date" 
          placeholder={t.dob} 
          className="w-full input-field"
          value={formData.dob}
          onChange={e => setFormData({...formData, dob: e.target.value})}
        />
      </div>
      
      <div className="space-y-1">
        <label className="text-[10px] font-bold text-white/40 px-1">{t.contact_email_label}</label>
        <input 
          type="email" 
          placeholder={t.email_placeholder} 
          className="w-full input-field"
          value={formData.email}
          onChange={e => setFormData({...formData, email: e.target.value})}
        />
      </div>
      
      <input 
        type="text" 
        placeholder={t.city_address} 
        className="w-full input-field"
        value={formData.city}
        onChange={e => setFormData({...formData, city: e.target.value})}
      />

      <div className="space-y-1">
        <label className="text-[10px] font-bold text-white/40 px-1">{t.delivery_experience}</label>
        <input 
          type="text" 
          placeholder={t.experience_placeholder} 
          className="w-full input-field"
          value={formData.experience}
          onChange={e => setFormData({...formData, experience: e.target.value})}
        />
      </div>
      
      <div className="space-y-1">
        <label className="text-[10px] font-bold text-white/40 px-1">{t.id_photo}</label>
        <div className="relative">
          <input 
            type="file" 
            accept="image/*"
            className="hidden" 
            id="id-upload"
            onChange={e => setFormData({...formData, idPhoto: e.target.files?.[0] || null})}
          />
          <label 
            htmlFor="id-upload"
            className="w-full p-4 bg-white/5 border-2 border-dashed border-white/10 rounded-2xl flex flex-col items-center gap-2 cursor-pointer hover:border-moov-gold transition-all"
          >
            <Plus className="w-6 h-6 text-moov-gold" />
            <span className="text-xs text-white/40">{formData.idPhoto ? formData.idPhoto.name : t.upload_id}</span>
          </label>
        </div>
      </div>

      <div className="flex gap-3 pt-4">
        <button onClick={() => setStep(1)} className="flex-1 py-3 text-white/40 font-bold">{t.back}</button>
        <button 
          onClick={() => {
            onSubmit(formData);
            setSubmitted(true);
          }}
          className="flex-1 btn-primary"
          disabled={!formData.name || !formData.email || !formData.city || !formData.experience}
        >
          {t.send_order}
        </button>
      </div>
    </div>
  );
}
